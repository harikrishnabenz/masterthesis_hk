"""Loads prior registered logger used for logging."""

import logging
import os

env_log_level = os.getenv("HLX_LOG_LEVEL", "").upper()

log_levels = {"DEBUG": logging.DEBUG, "INFO": logging.INFO, "WARNING": logging.WARNING, "ERROR": logging.ERROR}

log_level = log_levels.get(env_log_level, logging.WARNING)

logger = logging.getLogger("flytekit")
logger.setLevel(log_level)
