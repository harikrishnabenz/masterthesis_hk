"""SideCar Service Definitions."""

from typing import Optional

from kubernetes.client.models import V1Container

from hlx.wf.kubernetes import Resources
from hlx.wf.mounts import MountType

# Flag to let init container remain running throughout pod lifecycle
# Please see: https://kubernetes.io/docs/concepts/workloads/pods/sidecar-containers/
SIDE_CAR_RESTART_POLICY = "Always"


class SideCarService:
    """Interface of additional sidecar services.

    A single sidecar service is essentially another linux container running next to your task.
    Services running as sidecar may be accessed via localhost as they share same network namespace.
    Further reading: https://kubernetes.io/docs/concepts/workloads/pods/init-containers/
    """

    def get_spec(self) -> V1Container:
        """Returns V1Container spec."""

    def get_mounts(self) -> Optional[list[MountType]]:
        """Returns mounts."""

    def get_resources(self) -> Resources:
        """Returns requested Resources."""
        res = self.get_spec().resources
        if res and "requests" in res:
            return Resources.from_v1_container_resource(res["requests"])
        else:
            return Resources()


class CustomSidecarService(SideCarService):
    """Custom sidecar container implementation that accepts arbitrary V1Container definition."""

    def __init__(self, spec: V1Container, mounts: Optional[list[MountType]]):
        super().__init__()
        self.spec = spec
        # set limits equal to requests
        res = self.get_spec().resources
        if res:
            if "requests" in res:
                self.spec.resources["limits"] = res["requests"]
            if "requests" not in res and "limits" in res:
                self.spec.resources["requests"] = res["limits"]
        self.spec.restart_policy = SIDE_CAR_RESTART_POLICY
        self.mounts = mounts

    def get_spec(self) -> V1Container:
        """Returns V1Container spec."""
        return self.spec

    def get_mounts(self) -> Optional[list[MountType]]:
        """Returns mounts."""
        return self.mounts
