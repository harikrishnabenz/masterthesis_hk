"""Flyte dependant configuration information."""

import os
from dataclasses import dataclass
from enum import Enum
from typing import Optional

HELIX_INFRA_ENVIRONMENT = "HELIX_INFRA_ENVIRONMENT"
"""Environment variable that specifies which infrastructure to use (dev/int/prod)"""

HELIX_INSTANCE = "HELIX_INSTANCE"
"""Environment variable that specifies the instance to be used (MB)"""

MB_PROJECT_DEV = "mb-adas-2014-p-0eb1"
MB_PROJECT = "mb-adas-2015-p-a4db"
HELIX_ENABLE_REMOTE_DEBUG = "HELIX_ENABLE_REMOTE_DEBUG"
HLX_CONFIG_DIR = "HLX_CONFIG_DIR"


class Infra(str, Enum):
    """Different infrastructures of Flyte."""

    Dev = "dev"
    Prod = "prod"


class Domain(str, Enum):
    """Different domains available per team space."""

    Dev = "dev"
    Prod = "prod"


class Instance(str, Enum):
    """Instances of Flyte."""

    MB = "MB"
    LOCAL = "local"


def get_infra_helix_environment() -> str:
    """Returns which infrastructure is currently used."""
    return os.environ.get(HELIX_INFRA_ENVIRONMENT, Infra.Prod.value)


def get_helix_instance() -> str:
    """Returns the instance (MB)."""
    return os.environ.get(HELIX_INSTANCE, Instance.MB.value)


def get_docker_registry(helix_infra_environment: Optional[str], helix_instance: Optional[str]) -> str:
    """Returns the default docker registry for the current environment.

    If no environment is passed in via helix_environment argument, one will
    be tried to be taken from the environment variable HELIX_INFRA_ENVIRONMENT which will default to prod
    """
    if helix_infra_environment is None:
        helix_infra_environment = get_infra_helix_environment()

    if helix_instance is None:
        helix_instance = get_helix_instance()

    repo = {
        Instance.MB.value: {
            Infra.Dev.value: MB_PROJECT_DEV,
            Infra.Prod.value: MB_PROJECT,
        },
    }[helix_instance][helix_infra_environment]
    return f"europe-west4-docker.pkg.dev/{repo}"


def get_project_id(infra: Optional[Infra] = None) -> str:
    """Returns the project ID based on the infrastructure and Helix instance."""
    helix_instance = get_helix_instance()
    infra_env = get_infra_helix_environment() if infra is None else infra

    project_mapping = {
        (Instance.MB.value, Infra.Dev.value): MB_PROJECT_DEV,
        (Instance.MB.value, Infra.Prod.value): MB_PROJECT,
    }

    key = (helix_instance, infra_env)
    try:
        return project_mapping[key]
    except KeyError as error:
        message = f"The given infra ({infra_env}) or instance ({helix_instance}) is not valid."
        raise ValueError(message) from error


@dataclass
class InstanceConfig:
    """Configurations for different instances of Helix."""

    gcp_dns: str
    flyte_host: str


_INSTANCES: dict[Instance, dict[Infra, InstanceConfig]] = {
    Instance.MB: {
        Infra.Dev: InstanceConfig(
            gcp_dns="2014.helix.cloud.corpintra.net",
            flyte_host="workflows-dev.2014.helix.cloud.corpintra.net",
        ),
        Infra.Prod: InstanceConfig(
            gcp_dns="2015.helix.cloud.corpintra.net",
            flyte_host="workflows.2015.helix.cloud.corpintra.net",
        ),
    },
    Instance.LOCAL: {
        Infra.Dev: InstanceConfig(
            gcp_dns="localhost",
            flyte_host="localhost",
        ),
    },
}


def get_instances_config(instance: Instance, infra: Infra) -> InstanceConfig:
    """Returns the configuration for the given instance and infrastructure."""
    return _INSTANCES[instance][infra]
