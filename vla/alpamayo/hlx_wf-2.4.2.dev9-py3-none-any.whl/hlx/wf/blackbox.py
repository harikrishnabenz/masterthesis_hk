"""Blackbox Container Target for execution of arbitrary container images in flyte."""

import sys
from pathlib import Path
from typing import Optional, Union

import flytekit
from kubernetes.client.models import (
    V1Container,
    V1EnvVar,
    V1ResourceRequirements,
    V1VolumeMount,
)

from hlx.wf.config import get_docker_registry
from hlx.wf.mounts import RamDisk


class BlackboxContainerTarget:
    """A blackbox container image target. This enables using arbitrary container images in flyte.

    A python installation with flyte will be installed to the image at runtime.
    Use only when ImageSpec is not an option.
    """

    _TASK_TYPE = "blackbox-container-task"
    _ENV_FLYTE_DIR = "FLYTE_DIR"
    _ENV_FLYTE_PYTHON = "FLYTE_PYTHON"
    _ENV_FLYTE_USER_SUBDIR = "FLYTE_USER_SUBDIR"
    _ENV_FLYTE_RESET_PYTHONPATH = "FLYTE_RESET_PYTHONPATH"
    _FLYTE_VOLUME = "flyte-code"
    _FLYTE_INIT_CONTAINER = "flyte-init"
    _FLYTE_INIT_SCRIPT = Path("/flyte/bin/flyte-init.sh")
    _FLYTE_ENTRYPOINT_SCRIPT = Path("bin/flyte-entrypoint.sh")
    _FLYTE_USER_SUBDIR = Path("src")

    def __init__(
        self,
        container_image: str,
        *,
        flyte_dir: Union[str, Path] = Path("/flyte_code"),
        helix_environment: Optional[str] = None,
        clear_pythonpath: bool = False,
    ):
        """Initializes a blackbox container target.

        Args:
            container_image: The container image to use for execution.
            flyte_dir: The flyte installation and the user code will be placed below this directory.
                Should not exist, will be removed otherwise.
            helix_environment: Infrastructure environment to use for the container image.
            clear_pythonpath: Whether to clear PYTHONPATH env variable before execution.
        """
        self.clear_pythonpath = clear_pythonpath
        self.container_image = container_image
        self.flyte_dir = Path(flyte_dir)
        self.helix_environment = helix_environment

    def get_entrypoint(self) -> Path:
        """Get entrypoint script for the blackbox container image."""
        return self.flyte_dir / self._FLYTE_ENTRYPOINT_SCRIPT

    def get_working_dir(self) -> str:
        """Get working directory for the blackbox container image."""
        return (self.flyte_dir / self._FLYTE_USER_SUBDIR).as_posix()

    def get_container_image(self) -> str:
        """Get container image string for the blackbox container image."""
        return self.container_image

    def get_injection_env_vars(self) -> dict[str, str]:
        """Returns variables that need to be injected into the execution env for blackbox container."""
        clear_pythonpath = {self._ENV_FLYTE_RESET_PYTHONPATH: "1"} if self.clear_pythonpath else {}

        return {
            self._ENV_FLYTE_DIR: str(self.flyte_dir),
            self._ENV_FLYTE_RESET_PYTHONPATH: "",
            self._ENV_FLYTE_USER_SUBDIR: str(self._FLYTE_USER_SUBDIR),
            **clear_pythonpath,
        }

    def get_mounts(self):
        """Gets mounts needed for blackbox container image execution."""
        return [RamDisk(name=self._FLYTE_VOLUME, size_limit=None, mount_path=str(self.flyte_dir))]

    def _default_init_container_image(self):
        registry = get_docker_registry(helix_infra_environment=self.helix_environment, helix_instance=None)
        python_version_major, python_version_minor = sys.version_info[0:2]
        return (
            f"{registry}/flyte/flyte-playground:"
            f"flyte-{flytekit.__version__}-py-{python_version_major}.{python_version_minor}"
        )

    def get_init_container(self) -> V1Container:
        """Returns container spec intended to be used as init container."""
        python_interp = self.flyte_dir / "bin" / "python3"

        init_container = V1Container(
            name=self._FLYTE_INIT_CONTAINER,
            args=[str(self._FLYTE_INIT_SCRIPT)],
            env=[
                V1EnvVar(name=self._ENV_FLYTE_DIR, value=self.flyte_dir.as_posix()),
                V1EnvVar(name=self._ENV_FLYTE_PYTHON, value=python_interp.as_posix()),
                V1EnvVar(
                    name=self._ENV_FLYTE_USER_SUBDIR,
                    value=str(self._FLYTE_USER_SUBDIR),
                ),
            ],
            image=self._default_init_container_image(),
            image_pull_policy="Always",
            volume_mounts=[V1VolumeMount(name=self._FLYTE_VOLUME, mount_path=self.flyte_dir.as_posix())],
            resources=V1ResourceRequirements(limits={"cpu": "100m", "memory": "1G"}),  # we copy ~800m to a ram disk
        )
        return init_container
