"""Extension of the `flytekit.task`."""

import datetime as _datetime
import functools
import os
import sys
import types
import warnings
from collections import OrderedDict
from collections.abc import Mapping, Sequence
from dataclasses import asdict, replace
from functools import update_wrapper
from typing import (
    Any,
    Callable,
    Optional,
    Union,
    cast,
)

import flytekit.core.task
from flytekit.core.base_task import TaskMetadata
from flytekit.core.container_task import ContainerTask as FlyteContainerTask
from flytekit.core.pod_template import PodTemplate
from flytekit.core.python_function_task import PythonFunctionTask
from flytekit.core.task import T, TaskPlugins
from flytekit.models.security import Secret
from flytekitplugins.kfmpi import MPIJob

from hlx.wf.bazel import INVALID_BAZEL_TARGET, BazelTarget
from hlx.wf.blackbox import BlackboxContainerTarget
from hlx.wf.cache import Cache, CacheContext, CacheSettings, wrapper_cache_settings
from hlx.wf.compute import ComputeType
from hlx.wf.config import HELIX_ENABLE_REMOTE_DEBUG
from hlx.wf.container_images import (
    DEPENDENCIES_PIP,
    PIP_REGISTRY,
    ImageType,
    WorkingDirImage,
    determine_container_image,
)
from hlx.wf.internal import pod_utils as utils
from hlx.wf.kubernetes_secrets import KubernetesSecretEnv
from hlx.wf.loggers import logger
from hlx.wf.mounts import MountType
from hlx.wf.sidecar_services import SideCarService


def catch_and_log_error(func):
    """Decorator to catch, to log, and ordinary shutdown on error."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"{e}", exc_info=not isinstance(e, ValueError))
            sys.exit(1)

    return wrapper


@catch_and_log_error
def task(
    compute: ComputeType,
    mounts: Optional[Sequence[MountType]] = None,
    install_hlx_deps: bool = False,  # noqa: FBT002
    task_config: Optional[flytekit.core.task.T] = None,
    cache: Optional[Cache] = None,
    retries: int = 0,
    interruptible: Optional[bool] = None,
    deprecated: str = "",
    timeout: Union[_datetime.timedelta, int] = 0,
    container_image: Optional[ImageType] = None,
    environment: Optional[Mapping[str, Union[str, KubernetesSecretEnv]]] = None,
    execution_mode: PythonFunctionTask.ExecutionBehavior = PythonFunctionTask.ExecutionBehavior.DEFAULT,
    docs: Optional[flytekit.Documentation] = None,
    enable_deck: Optional[bool] = None,
    sidecar_services: Optional[Sequence[SideCarService]] = None,
):
    """Tasks are the building blocks of a workflow.

    This is is wrapper around the flytekit.task, removing the need and option to specify pod templates by the user.
    It makes it easy to specify compute and mounts in user friendly way.

    Note: When you specify a container image, it needs to have some dependencies installed.
    Therefore feel free to use one of the images we provide (`hlx.wf.container_images.ContainerImage`),
    or bring your own and get dependencies installed by setting the argument `install_hlx_deps` to `True` (deprecated
    use https://git.swf.i.mercedes-benz.com/helixpublic/Workflows/-/blob/main/docs/best_practices/hlx_deps.md).

    Flyte assumes it can upload your workflow python logic to the default working dir on your pods filesystem
    and it can be accessed by the user defined in the docker image.
    In case your container image cant fulfill this, feel free to change this directory via the `flyte_dir` argument.

    Besides that, this wrapper is behaving exactly the same as the flytekit.task does and gives you the same features.

    Args:
        _task_function: This argument is implicitly passed and represents the decorated function.
        compute: Specify your computation needs.
        mounts: Add additional mounts.
        install_hlx_deps: If True, it installs the HLX Workflows dependencies on top of your container image.
        task_config: This argument provides configuration for a specific task types.
        cache: Cache settings for the task. Use CacheWherePossible(), CacheByVersion(), or CacheSameImageOnly().
        retries: Number of times to retry this task during a workflow execution.
        interruptible: Boolean that indicates that this task can be interrupted and/or scheduled on nodes
                          with lower QoS guarantees. This will directly reduce the `$`/`execution cost` associated,
                          at the cost of performance penalties due to potential interruptions. Requires additional
                          Flyte platform level configuration. If no value is provided, the task will inherit this
                          attribute from its workflow, as follows:
                          No values set for interruptible at the task or workflow level - task is not interruptible
                          Task has interruptible=True, but workflow has no value set - task is interruptible
                          Workflow has interruptible=True, but task has no value set - task is interruptible
                          Workflow has interruptible=False, but task has interruptible=True - task is interruptible
                          Workflow has interruptible=True, but task has interruptible=False - task is not interruptible
        deprecated: A string that can be used to provide a warning message for deprecated task. Absence / empty str
                       indicates that the task is active and not deprecated.
        timeout: The max amount of time for which one execution of this task should be executed for. The execution
                    will be terminated if the runtime exceeds the given timeout (approximately).
        container_image: By default the configured FLYTE_INTERNAL_IMAGE is used for every task. This directive can be
                used to provide an alternate image for a specific task. This is useful for the cases in which images
                bloat because of various dependencies and a dependency is only required for this or a set of tasks,
                and they vary from the default.
        environment: Environment variables that should be added for this tasks execution, can also include references
                    to Kubernetes secrets.
        execution_mode: Ignore this. Flyte internal logic.
        docs: Documentation about this task.
        enable_deck: If true, this task will output deck html file.
        working_dir: Alternative path for uploading and executing the workflows on the pods filesystem.
        sidecar_services: Additional sidecar services deployed as special init containers that remain running.
    """
    if mounts is None:
        mounts = []
    else:
        mounts = list(mounts)
    if isinstance(container_image, BlackboxContainerTarget):
        mounts += container_image.get_mounts()

    compute.request_resources(mounts, sidecar_services)

    working_dir = container_image.working_dir if isinstance(container_image, WorkingDirImage) else None
    general_env_vars, secrets = utils.split_env_vars(environment or {})

    primary_env_vars = utils.add_helix_vars_to_env(secrets, working_dir)
    pod_template = utils.create_pod_template_for_primary_container(compute, mounts, primary_env_vars)
    if isinstance(container_image, BlackboxContainerTarget):
        utils.add_init_containers_to_pod_template(pod_template, [container_image.get_init_container()])

    if sidecar_services:
        utils.add_init_containers_to_pod_template(pod_template, [s.get_spec() for s in sidecar_services])

    mounts += utils.flatten_sidecar_mounts(sidecar_services)

    utils.add_volumes_to_pod_template(pod_template, mounts)
    utils.add_extra_labels_to_pod_template(pod_template, compute)

    # TODO: Change after issue is fixed - https://github.com/flyteorg/flyte/issues/5809
    utils.add_envs_to_all_containers(pod_template, general_env_vars)

    # In case of MPI job we have to copy resource requests/limits over
    if isinstance(task_config, MPIJob):
        task_config.launcher.requests = compute.requests()
        task_config.launcher.limits = compute.limits()
        task_config.worker.requests = compute.requests()
        task_config.worker.limits = compute.limits()

    task_args = {
        "task_config": task_config,
        "requests": compute.requests(),
        "limits": compute.limits(),
        "pod_template_name": compute.pod_template_name(),
        "pod_template": pod_template,
        "secret_requests": None,
        "execution_mode": execution_mode,
        "enable_deck": enable_deck,
        "docs": docs,
    }

    metadata_args = {
        "retries": retries,
        "interruptible": interruptible,
        "deprecated": deprecated,
        "timeout": timeout,
    }

    wrapper = _create_wrapper(
        environment=None,  # TODO: Change after issue is fixed - https://github.com/flyteorg/flyte/issues/5809
        container_image=determine_container_image(container_image),
        install_hlx_deps=install_hlx_deps,
        task_args=task_args,
        metadata_args=metadata_args,
        cache_settings=wrapper_cache_settings(cache),
    )

    logger.debug(
        "Pod spec where task gets embedded: %s", pod_template.pod_spec.to_str() if pod_template.pod_spec else ""
    )

    return wrapper


dynamic = functools.partial(task, execution_mode=PythonFunctionTask.ExecutionBehavior.DYNAMIC)  # type: ignore[var-annotated]


class ContainerTask(FlyteContainerTask):
    """This task variant represents a raw container, with no assumptions made about what is running within it.

    Args:
        name: Give it a name.
        image: Container image to run.
        command: Command executed on the container.
        compute: Specify your computation needs.
        mounts: Add additional mounts.
        inputs: Define inputs for the task.
        metadata: Metadata of the task.
        arguments: Passing arguments to commands within a container allows you to customize the command's behavior and
                   provide specific input data, enhancing flexibility and control over container operations.
        outputs: Expected outputs of the task.
        input_data_dir: Where inputs will be written to.
        output_data_dir: Where Flyte will expect the outputs to exist.
        metadata_format: Can be used to configure caching.
        io_strategy: Defines how data is downloaded or uploaded, either eagerly, streamed, or not at all.
        secret_request: A successful request allows containers to securely access sensitive data such as API keys,
                        passwords, and certificates managed by a secret manager, ensuring secure and
                        efficient operations.
        local_logs: Local logs for a container are the log files generated by the container's applications,
                    stored on the host machine, used for monitoring and troubleshooting. Note: This method works only
                    for services with the ``json-file``
        environment: Environment variables that should be added for this task's execution, can also include references
                    to Kubernetes secrets.
        sidecar_services: Additional sidecar services deployed as special init containers that remain running.
    """

    def __init__(
        self,
        name: str,
        image: Optional[Union[str, flytekit.ImageSpec]],
        command: list[str],
        compute: ComputeType,
        cache: Optional[Cache] = None,
        mounts: Optional[Sequence[MountType]] = None,
        inputs: Optional[OrderedDict[str, Any]] = None,
        metadata: Optional[TaskMetadata] = None,
        arguments: Optional[list[str]] = None,
        outputs: Optional[dict[str, Any]] = None,
        input_data_dir: Optional[str] = None,
        output_data_dir: Optional[str] = None,
        metadata_format: flytekit.ContainerTask.MetadataFormat = flytekit.ContainerTask.MetadataFormat.JSON,
        io_strategy: Optional[flytekit.ContainerTask.IOStrategy] = None,
        secret_requests: Optional[list[Secret]] = None,
        environment: Optional[dict[str, Union[str, KubernetesSecretEnv]]] = None,
        sidecar_services: Optional[Sequence[SideCarService]] = None,
        *,
        local_logs: bool = False,
        **kwargs,
    ):
        if mounts is None:
            mounts = []
        else:
            mounts = list(mounts)

        compute.request_resources(mounts, sidecar_services)

        primary_env_vars = utils.add_helix_vars_to_env(environment or {}, None)
        pod_template = utils.create_pod_template_for_primary_container(compute, mounts, primary_env_vars)

        if sidecar_services:
            utils.add_init_containers_to_pod_template(pod_template, [s.get_spec() for s in sidecar_services])

        sidecar_mounts = utils.flatten_sidecar_mounts(sidecar_services)
        if sidecar_mounts:
            mounts.extend(sidecar_mounts)

        utils.add_volumes_to_pod_template(pod_template, mounts)
        utils.add_extra_labels_to_pod_template(pod_template, compute)

        # TODO: Change after issue is fixed - https://github.com/flyteorg/flyte/issues/5809
        utils.add_envs_to_all_containers(pod_template, environment or {})

        container_image = determine_container_image(image)
        metadata = utils.update_metadata_with_cache_settings(cache, container_image, None, metadata)

        if not isinstance(container_image, (str, flytekit.ImageSpec)):
            error_msg = (
                "Container image must be a string or an instance of flytekit.ImageSpec. "
                f"Got {type(container_image)} instead."
            )
            raise ValueError(error_msg)

        super().__init__(
            name=name,
            image=container_image,
            command=command,
            inputs=inputs,
            metadata=metadata,
            arguments=arguments,
            outputs=outputs,
            requests=compute.requests(),
            limits=compute.limits(),
            input_data_dir=input_data_dir,
            output_data_dir=output_data_dir,
            metadata_format=metadata_format,
            io_strategy=io_strategy,
            secret_requests=secret_requests,
            pod_template=pod_template,
            local_logs=local_logs,
            kwargs=kwargs,
        )


class RemoteDebuggerTaskWrapper:
    """Wraps task function with remote debugger client port connection glue code.

    Executes function to wait for remote python debugger client connection before executing task function
    """

    def __init__(self, func):
        self.func = func
        functools.update_wrapper(self, func)

    def __call__(self, *args, **kwargs):
        """This function execute remote debugger port connection code before calling the task function."""
        logger.info("Debugger waiting for client connection...")
        return self.func(*args, **kwargs)


def _create_wrapper(
    *,  # make arguments keyword only to avoid confusions
    environment: Optional[dict[str, str]],
    container_image: ImageType,
    install_hlx_deps: bool,
    task_args: dict[str, Any],
    metadata_args: dict[str, Any],
    cache_settings: Callable[..., CacheSettings],
):
    def wrapper(fn: Callable[..., Any]) -> PythonFunctionTask[T]:
        image = container_image
        # wrap task function with remote debug connection code if debug envionment variable is set
        if HELIX_ENABLE_REMOTE_DEBUG in os.environ and os.environ[HELIX_ENABLE_REMOTE_DEBUG] == "1":
            fn = RemoteDebuggerTaskWrapper(fn)
            logger.info("Task function is wrapped with remote debug support code")
        cache_settings_data = cache_settings(CacheContext(image, fn))
        metadata_args.update(asdict(cache_settings_data))
        _metadata = TaskMetadata(**metadata_args)

        # Copy environment and container image into variables,
        # else wise strange things will happen
        final_environment = environment or {}
        final_working_dir: Optional[str] = None
        if isinstance(image, WorkingDirImage):
            final_working_dir = image.working_dir
            image = image.value
        if isinstance(image, BazelTarget):
            final_working_dir = image.get_working_dir(fn)
            env_vars = image.get_task_env_vars(fn)
            if final_working_dir:
                env_vars["PYTHONPATH"] = ":".join(
                    [final_working_dir] + ([env_vars["PYTHONPATH"]] if "PYTHONPATH" in env_vars else [])
                )
            if env_vars:
                final_environment = dict(env_vars, **environment) if environment else env_vars
            final_container_image: Union[str, None, flytekit.ImageSpec] = image.get_container_image(fn)
        elif isinstance(image, BlackboxContainerTarget):
            final_working_dir = image.get_working_dir()
            final_container_image = image.get_container_image()
            injection_env_vars = image.get_injection_env_vars()

            if environment is None:
                final_environment = injection_env_vars
            elif injection_env_vars is not None:
                final_environment = dict(
                    environment, **injection_env_vars
                )  # Overwrite with injection env vars to make sure those are correct
        else:
            final_container_image = image

        if install_hlx_deps:
            deprecation_message = " ".join(
                [
                    "The automatic installation of hlx dependencies within a provided image",
                    "is now implemented using the hlx-deps image. Please refer to the documentation:",
                    "https://git.swf.i.mercedes-benz.com/helixpublic/Workflows/-/blob/main/docs/best_practices/hlx_deps.md",
                ]
            )
            warnings.warn(
                deprecation_message,
                DeprecationWarning,
                stacklevel=2,
            )
            if isinstance(final_container_image, flytekit.ImageSpec):
                final_container_image.packages = final_container_image.packages or []
                final_container_image.packages.extend(DEPENDENCIES_PIP)
                extra_index_url = final_container_image.pip_extra_index_url or []
                if PIP_REGISTRY not in extra_index_url:
                    final_container_image.pip_extra_index_url = [*extra_index_url, PIP_REGISTRY]
            else:
                base_image = final_container_image
                final_container_image = flytekit.ImageSpec(
                    base_image=base_image,
                    packages=DEPENDENCIES_PIP,
                    pip_index=PIP_REGISTRY,
                )

        pod_template = cast(PodTemplate, task_args["pod_template"])

        utils.add_envs_to_all_containers(pod_template, final_environment)

        task_instance = TaskPlugins.find_pythontask_plugin(type(task_args["task_config"]))(
            task_function=fn,
            metadata=_metadata,
            container_image=final_container_image,
            environment=None,
            task_resolver=None,
            disable_deck=None,
            accelerator=None,
            **task_args,
        )
        if final_working_dir is not None or isinstance(container_image, BlackboxContainerTarget):
            # Workaround until Flyte supports this natively.
            # Downside: It changes the working_dir for all task.

            get_container_old = task_instance._get_container

            def get_container_new(self, settings):
                # Note the default working dir changed in flyte 1.11.0 to ".".
                # There is no way to obtain the default programmatically.
                if (
                    self.container_image
                    and settings.fast_serialization_settings.destination_dir in ["/root", "."]
                    and final_working_dir
                ):
                    if self.container_image == INVALID_BAZEL_TARGET:
                        error_msg = (
                            "Task is using bazel to build the workflow, but no image was specified for it. "
                            "Please make sure the task has a matching bazel rule"
                            "and that you are using bazel to launch it."
                        )
                        raise ValueError(error_msg)

                    # we have to use replace here otherwise we would modify the global default settings
                    fast_serialization_settings = replace(
                        settings.fast_serialization_settings,
                        destination_dir=final_working_dir,
                    )
                    settings = replace(
                        settings,
                        fast_serialization_settings=fast_serialization_settings,
                    )

                container = get_container_old(settings)
                if isinstance(container_image, BlackboxContainerTarget):
                    # blackbox containers need a specific entrypoint
                    container._command = [str(container_image.get_entrypoint())]
                return container

            task_instance._get_container = types.MethodType(get_container_new, task_instance)

        update_wrapper(task_instance, fn)
        return task_instance

    return wrapper


def create_init_hooks(compute: ComputeType, mounts: Sequence[MountType]) -> list[Callable[[], None]]:
    """Creates init hooks for the compute and all mounts.

    Args:
        compute: Compute to consider.
        mounts: list of mounts to consider.

    Returns:
        A list of functions that should be called in the beginning.
    """
    return compute.init_hooks() + [ih for m in mounts for ih in m.init_hooks()]
