"""Definition of helpers to run within Flyte tasks."""

import subprocess

import debugpy  # noqa: T100


def fuse_prefetch_metadata(path: str, timeout=1800):
    """Fetches metadata of a path mounted by FUSE in order to improve reading speed from this filesystem.

    Args:
        path: Path to prefetch metadata
        timeout: Maximum time in seconds for the prefetch operation to run (default is 1800 seconds)
    """
    subprocess.run(["/bin/ls", "-R", path], check=True, shell=True, timeout=timeout)  # noqa: S602


def start_debugging(port: int = 5678, wait_for_client: bool = True):  # noqa: FBT002
    """Enables Python debugging for a specified port in the pod.

    Args:
        port: port on which the debugger can attach to
        wait_for_client: Waiting for client to connect before starting application
    """
    debugpy.listen(("127.0.0.1", port))  # noqa: T100

    if wait_for_client:
        debugpy.wait_for_client()  # noqa: T100
