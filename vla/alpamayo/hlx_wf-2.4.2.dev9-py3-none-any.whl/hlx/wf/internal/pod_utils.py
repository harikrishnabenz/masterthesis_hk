"""Utils for handling kubernetes pod specs."""

from collections.abc import Mapping, Sequence
from dataclasses import asdict
from json import dumps
from typing import (
    Any,
    Callable,
    Optional,
    Union,
    cast,
)

from flytekit.core.base_task import TaskMetadata
from flytekit.core.pod_template import PodTemplate
from kubernetes.client.models import V1Container, V1EnvVar, V1PodSpec, V1Volume

from hlx.wf.__about__ import __version__
from hlx.wf.cache import Cache, CacheContext, wrapper_cache_settings
from hlx.wf.compute import ComputeType
from hlx.wf.config import HELIX_INSTANCE, get_helix_instance
from hlx.wf.container_images import ImageType
from hlx.wf.kubernetes import HumanReadableUnit
from hlx.wf.kubernetes_secrets import KubernetesSecretEnv
from hlx.wf.mounts import FuseBucket, MountType
from hlx.wf.sidecar_services import SideCarService

MAX_NUMBER_ENV_VARS = 10**6
PRIMARY_CONTAINER_NAME = "primary"
POD_LABEL_SDK_VERSION = "hlx-sdk-version"


def update_metadata_with_cache_settings(
    cache: Optional[Cache],
    container_image: Optional[ImageType],
    flyte_task: Optional[Callable[..., Any]] = None,
    metadata: Optional[TaskMetadata] = None,
) -> TaskMetadata:
    """Updates metadata with cache settings. If cache settings are provided they are overwritten in metadata.

    Args:
        cache: Cache settings for the task.
        container_image: The container image to use for the task.
        flyte_task: the task to cache.
        metadata: Metadata of the task.

    Returns:
        Updated metadata with cache settings.
    """
    if cache is None:
        return metadata or TaskMetadata()

    cache_settings = wrapper_cache_settings(cache)
    cache_settings_data = cache_settings(CacheContext(container_image, flyte_task))

    if metadata is None:
        return TaskMetadata(**asdict(cache_settings_data))
    meta_data_args = metadata.__dict__
    meta_data_args.update(asdict(cache_settings_data))
    return TaskMetadata(**meta_data_args)


def flatten_sidecar_mounts(sidecar_services: Optional[Sequence[SideCarService]]) -> list[MountType]:
    """Flattens the mounts of all sidecar services into a single list."""
    mounts: list[MountType] = []
    if sidecar_services:
        for s in sidecar_services:
            sidecar_mounts: Optional[list[MountType]] = s.get_mounts()
            if sidecar_mounts:
                mounts.extend(sidecar_mounts)
    return mounts


def split_env_vars(
    environment: Optional[Mapping[str, Union[str, KubernetesSecretEnv]]] = None,
) -> tuple[dict[str, str], dict[str, KubernetesSecretEnv]]:
    """Split environment variables in secrets and regulars ensuring they are in the correct format and within limits."""
    straight_env: dict[str, str] = {}
    secrets: dict[str, KubernetesSecretEnv] = {}

    if environment is not None:
        if len(environment) > MAX_NUMBER_ENV_VARS:  # SecHub CWE-606
            msg = f"""Unsupported amount of environment variables set.
                Allowed: {MAX_NUMBER_ENV_VARS}, provided: {len(environment)}"""
            raise ValueError(msg)
        for key, value in environment.items():
            if isinstance(value, str):
                straight_env[key] = value
            elif isinstance(value, KubernetesSecretEnv):
                secrets[key] = value
            else:
                msg = f"Unsupported type for environment variable {key}: {type(value)}"
                raise TypeError(msg)

    return straight_env, secrets


def add_additional_envs_to_primary_container(
    pod_template: PodTemplate,
    envs: Mapping[str, Union[str, KubernetesSecretEnv]],
):
    """This function adds env vars passed to task decorator using param environment to primary container."""
    if pod_template.pod_spec is None or pod_template.pod_spec.containers is None:
        msg = "Received invalid pod spec"
        raise RuntimeError(msg)
    containers = pod_template.pod_spec.containers
    primary_container = next((container for container in containers if container.name == PRIMARY_CONTAINER_NAME), None)
    if primary_container is None:
        msg = f"Primary container '{PRIMARY_CONTAINER_NAME}' not found in pod spec."
        raise RuntimeError(msg)
    v1_container = cast(V1Container, primary_container)
    container_env = v1_container.env or []
    v1_container.env = _unique_envs(container_env + project_env_vars_to_k8s(envs))


def add_envs_to_all_containers(
    pod_template: PodTemplate,
    envs: Mapping[str, Union[str, KubernetesSecretEnv]],
):
    """This function adds env vars passed to task decorator using param environment to every container.

    Init containers do not get these env vars.

    Actually this the same as flytekit does. Due to an issue we have to do it on our own.
    Original implementation can be found in method _serialize_pod_spec of file flytekit/core/utils.py.

    Env vars created by SDK take precedence in case there are any naming collisions.

    Related issue: https://github.com/flyteorg/flyte/issues/5809
    """
    if pod_template.pod_spec is None or pod_template.pod_spec.containers is None:
        msg = "Received invalid pod spec"
        raise RuntimeError(msg)

    if envs:
        envs_clean = project_env_vars_to_k8s(envs)
        for container in pod_template.pod_spec.containers:
            v1_container = cast(V1Container, container)
            container_env = v1_container.env or []
            v1_container.env = _unique_envs(envs_clean + container_env)


def create_pod_template_for_primary_container(
    compute: ComputeType,
    mounts: Sequence[MountType],
    env_variables: Mapping[str, Union[str, KubernetesSecretEnv]],
) -> PodTemplate:
    """Creates a template for pod creation.

    Args:
        compute: Compute to consider in the template.
        mounts: list of mounts to consider in the template.
        env_variables:  Kubernetes environment variables including references to Kubernetes secrets

    Returns:
        A pod template for the given compute and mounts.
    """
    volume_mounts: Optional[list] = [vm for m in mounts for vm in m.volume_mounts()]

    # We can pass an empty list to the pod_spec. This would result in not scheduling.
    # If there is no volume (mount), the value needs to be None.
    if not volume_mounts:
        volume_mounts = None

    containers = [
        V1Container(
            name=PRIMARY_CONTAINER_NAME,
            volume_mounts=volume_mounts,
            image_pull_policy="Always",  # This needed when tag refers to a new (overridden) image.
            env=project_env_vars_to_k8s(env_variables),
        ),
    ]

    return PodTemplate(
        annotations=get_annotations(mounts, compute),
        pod_spec=V1PodSpec(containers=containers, node_selector=compute.node_selector(), affinity=compute.affinity()),
    )


def add_volumes_to_pod_template(pod_template: PodTemplate, mounts: list[MountType]) -> PodTemplate:
    """Adds volumes to a given PodTemplate."""
    volumes: Optional[list] = [v for m in mounts for v in m.volumes()]
    # We can pass an empty list to the pod_spec. This would result in not scheduling.
    # If there is no volume (mount), the value needs to be None.
    if not pod_template.pod_spec:
        msg = "Received invalid pod spec"
        raise RuntimeError(msg)
    if not volumes:
        volumes = None
    else:
        volumes = _unique_volumes(volumes)

    pod_template.pod_spec.volumes = volumes
    return pod_template


def add_init_containers_to_pod_template(
    pod_template: PodTemplate,
    init_containers: Optional[list[V1Container]],
) -> PodTemplate:
    """Adds init containers to a given PodTemplate.

    Note it doesn't perform any checks like uniqueness of container names.

    Args:
        pod_template: PodTemplate to be extended
        init_containers: May contain sidecar-init as well as regular-init containers

    Returns:
        A pod template for the given arguments.
    """
    if pod_template.pod_spec is None:
        msg = "Received invalid pod spec"
        raise RuntimeError(msg)
    if init_containers and len(init_containers) > 0:
        pod_template.pod_spec.init_containers = pod_template.pod_spec.init_containers or []
        pod_template.pod_spec.init_containers.extend(init_containers)

    return pod_template


def _unique_volumes(volumes: list[V1Volume]) -> list[V1Volume]:
    unique_volumes = {}
    for v in volumes:
        unique_volumes[dumps(v.to_dict(), sort_keys=True)] = v

    return list(unique_volumes.values())


def _unique_envs(envs: list[V1EnvVar]) -> list[V1EnvVar]:
    """Returns a list of unique environment variables based on their names."""
    unique_envs = {}
    for env in envs:
        unique_envs[env.name] = env

    return list(unique_envs.values())


def add_extra_labels_to_pod_template(pod_template: PodTemplate, compute: ComputeType):
    """Adds extra labels to a given PodTemplate."""
    if pod_template.labels is None:
        pod_template.labels = {}
    pod_template.labels[POD_LABEL_SDK_VERSION] = __version__
    pod_labels = compute.pod_labels()
    if pod_labels:
        pod_template.labels.update(pod_labels)


def project_env_vars_to_k8s(
    env_variables: Mapping[str, Union[str, KubernetesSecretEnv]],
) -> list[V1EnvVar]:
    """Converts Kubernetes secrets to environment variables for the primary container."""

    def project(name: str, env_var: Union[str, KubernetesSecretEnv]) -> V1EnvVar:
        if isinstance(env_var, KubernetesSecretEnv):
            return env_var.to_kubernetes_ref(name)
        else:
            return V1EnvVar(name=name, value=env_var)

    return [project(name, env_var) for name, env_var in env_variables.items()]


def add_helix_vars_to_env(
    env_variables: Mapping[str, Union[str, KubernetesSecretEnv]],
    working_dir: Optional[str] = None,
) -> dict[str, Union[str, KubernetesSecretEnv]]:
    """Adds Helix specific environment variables to the list of environment variables."""
    env_variables = dict(env_variables)  # Ensure we have a mutable copy
    env_variables[HELIX_INSTANCE] = get_helix_instance()

    if working_dir is not None:
        if "PYTHONPATH" in env_variables:
            env_variables["PYTHONPATH"] = f"{working_dir}:{env_variables['PYTHONPATH']}"
        else:
            env_variables["PYTHONPATH"] = working_dir

    return env_variables


def get_annotations(mounts: Sequence[MountType], compute: ComputeType) -> dict:
    """Returns a dictionary of annotations for the pod."""
    annotations: dict[str, str] = {}

    fuse_annotations = get_fuse_bucket_annotations(mounts)
    if fuse_annotations:
        annotations.update(fuse_annotations)

    compute_annotations = compute.pod_annotations()
    if compute_annotations:
        annotations.update(compute_annotations)
    return annotations


def get_fuse_bucket_annotations(mounts: Sequence[MountType]) -> Optional[dict[str, str]]:
    """Add annotations in order to start a GCS FUSE sidecar container."""
    fuse_buckets = list(filter(lambda volume: isinstance(volume, FuseBucket), mounts))
    if fuse_buckets:
        sum_storage = sum(
            [bucket.storage_reservation() for bucket in fuse_buckets], HumanReadableUnit("0", forbid_zero=False)
        )
        return {
            "gke-gcsfuse/cpu-limit": "0",
            "gke-gcsfuse/ephemeral-storage-limit": f"{int(sum_storage.value_rounded('Gi'))}Gi",
            "gke-gcsfuse/memory-limit": "0",
            "gke-gcsfuse/volumes": "true",
        }
    else:
        return None
