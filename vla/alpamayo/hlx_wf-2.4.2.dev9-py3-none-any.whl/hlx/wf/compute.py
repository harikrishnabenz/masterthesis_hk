"""Definition of compute types."""

import copy
import warnings
from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import Optional, Union, cast

from kubernetes.client.models import (
    V1Affinity,
)
from pytimeparse.timeparse import timeparse

from hlx.wf.cluster import (
    DEFAULT_MAX_DURATION,
    DWS_MAX_DURATION_SECONDS,
    DWS_MIN_DURATION_SECONDS,
    KUEUE_JOB_KEY,
    KUEUE_LOCAL_QUEUE_KEY,
    KUEUE_LOCAL_QUEUE_NON_DWS,
    ARMCPUNode,
    CPUNode,
    DwsStatus,
    GPUAccelerator,
    GPUNode,
    NodeBase,
)
from hlx.wf.kubernetes import (
    K8S_GPU_RESOURCE_KEY,
    UNITS,
    HumanReadableUnit,
    PodFeature,
    Resources,
)
from hlx.wf.loggers import logger
from hlx.wf.mounts import SHM_MAX_VALUE, FuseBucket, MountType, ShdMem
from hlx.wf.nodepool import Node
from hlx.wf.sidecar_services import SideCarService


class ComputeType(PodFeature, ABC):
    """Base class for specifying compute requirements of a task."""

    @abstractmethod
    def requests(self) -> Resources:
        """Minimum resource amount to be allocated.

        Request can possibly be allocated more resources than it requests.

        Return:
            Resource request for compute.
        """
        raise NotImplementedError

    @abstractmethod
    def limits(self) -> Optional[Resources]:
        """Maximum resource amount to be allocated.

        Limits are hard constraints.

        Return:
            Resource limits for compute.
        """
        raise NotImplementedError

    def pod_template_name(self) -> Optional[str]:
        """The name of an existing PodTemplate in K8 which will be used in this task.

        Return:
            Name of the pod template.
        """
        return None

    def node_selector(self) -> Optional[dict[str, str]]:
        """The node_selector entry in the pod spec.

        Return:
            A Dict of node selectors.
        """
        return None

    def pod_annotations(self) -> Optional[dict[str, str]]:
        """Returns additional annotations meant for pod spec.

        Return:
            A Dict of annotations.
        """
        return None

    def pod_labels(self) -> Optional[dict[str, str]]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        return None

    def affinity(self) -> Optional[V1Affinity]:
        """The affinity entry in the pod spec.

        Return:
            Instance of V1Affinity.
        """
        return None

    def _check_shared_memory_fits(self, shd_mem_requested: Union[HumanReadableUnit, str, None]):
        resources = self.limits() or self.requests()
        if not resources.mem:
            return
        if shd_mem_requested == SHM_MAX_VALUE or shd_mem_requested is None:
            return
        shared_mem_hru = HumanReadableUnit(shd_mem_requested)
        available_mem_hru = HumanReadableUnit(resources.mem)
        if shared_mem_hru.base_unit_rounded() > available_mem_hru.base_unit_rounded():
            msg = f"Requested {shared_mem_hru} of memory, but the node only has {available_mem_hru} available."
            raise ValueError(msg)

    def request_resources(
        self,
        mounts: Sequence[MountType],
        sidecar_services: Optional[Sequence[SideCarService]],  # noqa: ARG002
    ) -> None:
        """Check if the resource requests can be satisfied.

        If the resource requests cannot be fulfilled an error is raised.
        """
        requested_shd_mems = [m for m in mounts if isinstance(m, ShdMem)]
        if len(requested_shd_mems) > 1:
            msg = f"Shared memory volume can only be requested once but you asked for {len(requested_shd_mems)}"
            raise ValueError(msg)
        # Check if shm is within limit if set
        elif len(requested_shd_mems) == 1:
            self._check_shared_memory_fits(requested_shd_mems[0].size_limit)


class SharedNode(ComputeType):
    """Defines a compute requirement that allows running the job together with others on the same node.

    This class allows the K8 cluster to utilize the resources more efficiently by using nodes that still have
    resources available instead of spinning up a new node for each job.
    This is good for flexibility of cluster scaling, but creates challenges when using GPUs.

    Recommendation:
    Use `SharedNode` for CPU only workloads. If you need another accelerator, like GPUs,
    have a look at `DedicatedNode`.

    Note:
    By default the parameter `request_eq_limits` is activated and makes sure that not specified limits
    are set to the same values as the request. Whereas this is not the default Kubernetes or Flyte
    behavior, it prevents that your task gets flaky when you consume more resources as specified:
    Whenever you get a node which has enough resources, your task may succeed even if you consumed
    more than requested. But next time it could fail because the node provided only the resources
    you requested. By setting the limits, the task always fails, which gives you the hint to adapt
    your request. If you know what your doing, you can of course switch to the default
    Kubernetes / Flyte behavior by setting `request_eq_limits` to `False`.

    Args:
        requests: Minimum resource amount to be allocated.
        limits: Maximum resource amount to be allocated.
        request_eq_limits: If True and limits are None, request equals the limits.
        platform_arch: Node platform architecture if arm64 is required. Defaults to None (standard x86_64).
    """

    def __init__(
        self,
        requests: Optional[Resources] = None,
        limits: Optional[Resources] = None,
        request_eq_limits: bool = True,  # noqa: FBT002
        platform_arch: Optional[str] = None,
    ):
        """SharedNode constructor.

        Note on requests: The scheduler will use the requests value to find a matching node. The job is guaranteed to
        get at least the requested resources. It is possible to exceed the requested resources up to the specified
        limits if the node has more resources available, but there is no guarantee. This means that the job may fail
        if it exceeds the requested resources, e.g., because the node runs out of memory.

        Note on limits: It will not be possible to exceed the requested limits.
        Exceeding the requested memory may even result in termination of the pod.

        Args:
            requests: Minimum resource amount to be allocated.
            limits: Maximum resource amount to be allocated.
            request_eq_limits: If True and limits are None, request equals the limits.
            platform_arch: Node platform architecture if arm64 is required. Defaults to None (standard x86_64).
        """
        super().__init__()

        if (requests is None or requests == Resources()) and limits is not None and not limits == Resources():
            self._requests = limits
            logger.warning("Resource requests were None or empty, but limits have been set. Using limits as requests.")
        else:
            self._requests = requests or Resources()

        self._limits = self._requests if request_eq_limits and limits is None else limits
        self.nodes: Optional[list[Union[CPUNode, ARMCPUNode]]] = None
        self.platform_arch = platform_arch

    def requests(self) -> Resources:
        """Minimum resource amount needed by the task."""
        return self._requests

    def limits(self) -> Optional[Resources]:
        """Maximum resource amount needed by the task."""
        return self._limits

    def pod_template_name(self) -> Optional[str]:
        """The name of a existing PodTemplate in K8 which will be used in this task."""
        if self.platform_arch == "arm64":
            return "flyte-arm-cpu-template"
        return "flyte-cpu-template"

    def affinity(self) -> Optional[V1Affinity]:
        """Gets the affinity entry in the pod spec."""
        if not self.nodes:
            msg = "request_resources() must be called before accessing requests."
            raise ValueError(msg)

        return None

    def pod_labels(self) -> Optional[dict[str, str]]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        return {KUEUE_JOB_KEY: "false"}

    @staticmethod
    def _any_sidecar_service_requires_gpu(sidecar_services: Optional[Sequence[SideCarService]]) -> bool:
        if not sidecar_services:
            return False

        def contains_gpu(resources) -> bool:
            if resources:
                for k in ["requests", "limits"]:
                    if k in resources:
                        if K8S_GPU_RESOURCE_KEY in resources[k] and int(resources[k][K8S_GPU_RESOURCE_KEY]) > 0:
                            return True
            return False

        return any(contains_gpu(s.get_spec().resources) for s in sidecar_services)

    def request_resources(
        self, mounts: Sequence[MountType], sidecar_services: Optional[Sequence[SideCarService]]
    ) -> None:
        """Check if the resource requests can be satisfied and adjust the request if necessary."""
        super().request_resources(mounts, sidecar_services)

        msg = "GPUs are currently not supported for SharedNode. You may want to use DedicatedNode."
        if (
            self._requests.gpu is not None
            or (self._limits is not None and self._limits.gpu is not None)
            or self._any_sidecar_service_requires_gpu(sidecar_services)
        ):
            raise ValueError(msg)

        # Sort nodes by cpu and memory to select the smallest possible one
        cpu_nodes = sorted([x.value for x in Node if isinstance(x.value, CPUNode)])

        selection_criterion = self._requests

        if sidecar_services:
            selection_criterion = cast(
                Resources, sum([s.get_resources() for s in sidecar_services], selection_criterion)
            )

        logger.info(f"Requesting resources: {selection_criterion}")

        # In case of no specified resources, just use the smallest node type
        if selection_criterion == Resources():
            self.nodes = cpu_nodes
        else:
            self.nodes = self._select_node(cpu_nodes, selection_criterion)
        if not self.nodes:
            err_msg = (
                "No node found that could host the given resources. ",
                f"Requesting resources: {selection_criterion} -- Available max CPU node: {cpu_nodes[-1]} ",
            )
            raise ValueError(err_msg)
        logger.info(f"Matching nodepool(s) found: {len(cpu_nodes)}")

    @staticmethod
    def _select_node(cpu_nodes: list[CPUNode], request: Resources) -> list[CPUNode]:
        """Selects the node that best fits the selection criterion.

        Args:
            cpu_nodes: List of available nodes.
            request: The selection criterion.

        Returns:
            List of nodes that fit the selection criterion.
        """
        if request.cpu is None or request.mem is None:
            err_msg = f"Requesting resources must contain cpu and mem. Requested resources: {request}"
            raise ValueError(err_msg)

        ideal_node = CPUNode(
            cpu=HumanReadableUnit(request.cpu),
            mem=HumanReadableUnit(request.mem),
            ephemeral_storage=HumanReadableUnit(request.ephemeral_storage, forbid_zero=False),
            selection_label="fictional",
        )

        return list(filter(lambda x: x.all_greater_equal(ideal_node), cpu_nodes))


class DedicatedNode(ComputeType):
    """Compute type for jobs that are supposed to run exclusively on a node.

    No other pods will be scheduled on this node. This is good if you dont want any interference, e.g.,
    for GPU/TPU based computations/trainings. But it also limits scaling of the cluster.

    Recommendation:
    Use `SharedNode` for CPU only workloads. If you need another accelerator, like GPUs or TPUs,
    use `DedicatedNode`.

    Attention! We support the "max" value for `ephemeral_storage`, but we recommend
    to specify your real request (feel free to use our monitoring to find out the values).
    Depending on the nodes and the cluster, the "max" value could change over time and bring your
    task to crash during runtime. But specifying your request, we could give you feedback before even
    starting your workflow, so you don't have to debug what went wrong. Could save you some time ;)

    Args:
        node: Node definition via the nodepool.
        ephemeral_storage: Storage tied to the lifecycle of a pod, so when a pod finishes, that storage is cleared out.
            Alternatively, you can also specify "max" to get the maximum available ephemeral storage on the node.
        max_duration: Specifies estimated max computation time. The lower the value the lower the provisioning time.
            Sample value: "3d5h26m". Defaults to 7 days. Minimum val = 10 minutes.
            This is only required for GPU nodes with DWS enabled.
    """

    def __init__(self, node: Node, ephemeral_storage: Optional[str], max_duration: Optional[str] = None):
        super().__init__()
        self.node = self._get_node_value(node)
        self._requests: Optional[Resources] = None

        if ephemeral_storage == "max":
            self.ephemeral_storage = None
        elif ephemeral_storage:
            self.ephemeral_storage = HumanReadableUnit(ephemeral_storage)
        else:
            self.ephemeral_storage = HumanReadableUnit("0", forbid_zero=False)

        self.max_duration_seconds = self._check_and_get_max_duration(self.node, max_duration)

    def requests(self) -> Resources:
        """Minimum resource amount to be allocated."""
        if not isinstance(self._requests, Resources):
            msg = "request_resources() must be called before accessing requests."
            raise ValueError(msg)
        requests = copy.deepcopy(self._requests)
        if requests.cpu is None or requests.mem is None:
            msg = f"Invalid resources requested, expected cpu and mem to be set, got {requests}"
            raise ValueError(msg)
        # Take 0.6 of the available resources of the node to be requested -
        # if required the pod can consume up to the limit
        requests.cpu = str(HumanReadableUnit(requests.cpu) * 0.6)
        requests.mem = str(HumanReadableUnit(requests.mem) * 0.6)
        return requests

    def limits(self) -> Resources:
        """Maximum resource amount to be allocated.

        To not waste CPU cycles we doubled value of CPU cores being available.
        Flyte would copy values from requests in case we set limits to None.

        Return:
            Resource limits for compute.
        """
        if not isinstance(self._requests, Resources):
            msg = "request_resources() must be called before accessing requests."
            raise ValueError(msg)
        return copy.deepcopy(self._requests)

    def pod_template_name(self) -> Optional[str]:
        """The name of a existing PodTemplate in K8 which will be used in this task."""
        return "dedicated-node-template"

    def node_selector(self) -> Optional[dict[str, str]]:
        """Sets the node_selector entry in the pod spec."""
        if (
            self.max_duration_seconds
            and isinstance(self.node, GPUNode)
            and self.node.dws in [DwsStatus.ENABLED, DwsStatus.RECOMMENDED]
            and self.max_duration_seconds <= DWS_MAX_DURATION_SECONDS
        ):
            return self.node.node_selector_dws(self.max_duration_seconds)
        return self.node.node_selector()

    def pod_annotations(self) -> dict[str, str]:
        """Returns additional annotations meant for pod spec."""
        node_annotation = self.node.pod_annotations()
        return {**node_annotation}

    def pod_labels(self) -> Optional[dict[str, str]]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        use_local_queue = self.max_duration_seconds and self.max_duration_seconds > DWS_MAX_DURATION_SECONDS
        local_kueue_labels = {KUEUE_LOCAL_QUEUE_KEY: KUEUE_LOCAL_QUEUE_NON_DWS} if use_local_queue else {}
        return {**self.node.pod_labels(), **local_kueue_labels}

    def request_resources(
        self, mounts: Sequence[MountType], sidecar_services: Optional[Sequence[SideCarService]]
    ) -> None:
        """Check if the resource requests can be satisfied and adjust the request if necessary."""
        sidecar_resources = cast(Resources, sum([s.get_resources() for s in sidecar_services or []], Resources()))
        self._validate_storage(mounts, sidecar_resources)
        requests = self._calculate_request_resources()
        self._validate_gpu_usage(requests, sidecar_resources)

        logger.info(f"Requesting resources: {requests}")
        self._requests = requests - sidecar_resources
        super().request_resources(mounts, sidecar_services)

    def _validate_storage(self, mounts: Sequence[MountType], sidecar_resources: Resources) -> None:
        requested_ephemeral_storage = HumanReadableUnit(self.ephemeral_storage, forbid_zero=False) + HumanReadableUnit(
            sidecar_resources.ephemeral_storage, forbid_zero=False
        )

        total_needed_storage = sum(
            (bucket.storage_reservation() for bucket in mounts if isinstance(bucket, FuseBucket)),
            requested_ephemeral_storage,
        )

        if total_needed_storage > self.node.ephemeral_storage:
            msg = (
                f"You requested {total_needed_storage} of ephemeral_storage (including fuse mounts), "
                f"but the node only has {self.node.ephemeral_storage} available."
            )
            raise ValueError(msg)

    def _validate_gpu_usage(self, request: Resources, sidecar_resources: Resources) -> None:
        sidecar_gpu = HumanReadableUnit(sidecar_resources.gpu, forbid_zero=False)
        request_gpu = HumanReadableUnit(request.gpu, forbid_zero=False)
        if sidecar_gpu > request_gpu:
            msg = f"You requested {sidecar_gpu!s} gpu(s), but the node only has {request.gpu} available."
            raise ValueError(msg)

    def _calculate_request_resources(self) -> Resources:
        """Calculate request resources."""
        applied_ephemeral_storage = None
        if self.ephemeral_storage is not None:
            applied_ephemeral_storage = str(self.ephemeral_storage)

        mem_request = self.node.mem.base_unit() / UNITS["M"]

        gpu_request = str(self.node.gpu_number) if isinstance(self.node, GPUNode) else None

        return Resources(
            cpu=f"{self.node.cpu.base_unit():.2f}",
            mem=f"{mem_request:.2f}M",
            gpu=gpu_request,
            ephemeral_storage=applied_ephemeral_storage,
        )

    @staticmethod
    def _get_node_value(node: Node):
        """Returns the value of the GPU node and issues a warning if the GPU type is A100-40GB, P100, or T4."""
        node_value = node.value
        if hasattr(node_value, "gpu_type"):
            if node_value.gpu_type == GPUAccelerator.A100_40GB:
                warnings.warn(
                    f"\n⚠️  WARNING: {node_value.gpu_type} GPUs are no longer offered.\n"
                    f"The workflow will likely take longer to be scheduled, or it may not be scheduled at all.\n"
                    f"Please update your workflow to use a different GPU type.\n",
                    UserWarning,
                    stacklevel=2,
                )
            elif node_value.gpu_type == GPUAccelerator.P100:
                warnings.warn(
                    f"\n⚠️  DEPRECATION WARNING: {node_value.gpu_type} GPUs will be deprecated on 15th Sep. 2026.\n"
                    f"Please migrate your workflows to use a different GPU type before this date.\n",
                    UserWarning,
                    stacklevel=2,
                )
            elif node_value.gpu_type == GPUAccelerator.T4:
                warnings.warn(
                    f"\n⚠️  DEPRECATION WARNING: {node_value.gpu_type} GPUs will be deprecated soon.\n"
                    f"Please migrate your workflows to use a different GPU type.\n",
                    UserWarning,
                    stacklevel=2,
                )

        return node_value

    @staticmethod
    def _check_and_get_max_duration(node: NodeBase, max_duration: Optional[str]) -> Optional[float]:
        if max_duration:
            if not isinstance(node, GPUNode) or node.dws == DwsStatus.DISABLED:
                warnings.warn(
                    " ".join(
                        [
                            "max_duration is set but DWS is not enabled for selected node.",
                            "It's only available for A100_80GB, L4, and H100 accelerated nodes.",
                        ]
                    ),
                    DeprecationWarning,
                    stacklevel=2,
                )
            max_duration_seconds = timeparse(max_duration)
            if max_duration_seconds is None:
                err_msg = f"max_duration is {max_duration} but must be a valid time string."
                raise ValueError(err_msg)
            if max_duration_seconds < DWS_MIN_DURATION_SECONDS:
                err_msg = f"max_duration is {max_duration_seconds}s but must be at least {DWS_MIN_DURATION_SECONDS}s."
                raise ValueError(err_msg)
            return max_duration_seconds

        if isinstance(node, GPUNode):
            if node.dws == DwsStatus.RECOMMENDED:
                logger.warning("Fallback to default max_duration of 7d1h. This might cause longer provisioning time")
            return DEFAULT_MAX_DURATION
        return None


class DedicatedAccNode(DedicatedNode):
    """Deprecated: DedicatedAccNode was renamed to DedicatedNode."""

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        warnings.warn(
            "DedicatedAccNode was renamed to DedicatedNode and will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__init__(*args, **kwargs)
