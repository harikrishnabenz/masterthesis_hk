"""Remote Config. Partially ported from helix-cli/src/hlx_cli/lib/workflow/remote.py."""

from textwrap import dedent

import certifi
import grpc
import requests
from flyteidl.service import admin_pb2_grpc as _admin_service
from flyteidl.service import dataproxy_pb2_grpc as dataproxy_service
from flyteidl.service import signal_pb2_grpc as signal_service
from flytekit.clients.auth.authenticator import ClientConfig, ClientConfigStore
from flytekit.clients.auth_helper import (
    get_authenticator,
    get_channel,
    wrap_exceptions_channel,
)
from flytekit.clients.friendly import SynchronousFlyteClient
from flytekit.clients.grpc_utils.auth_interceptor import AuthUnaryInterceptor
from flytekit.configuration import AuthType, PlatformConfig
from flytekit.configuration import Config as FlyteConfig
from flytekit.loggers import logger
from flytekit.remote.remote import FlyteRemote

from hlx.wf.config import Domain, Infra, Instance, InstanceConfig, get_instances_config
from hlx.wf.credentials import Credentials

AUTH_META_DATA_ENDPOINT = "/hwfm/v1/authmetadataservice/publicclientconfig"
CODE_OK = 200


class WorkflowsRemoteClientConfigStore(ClientConfigStore):
    """Worklows implementation of ClientConfigStore to control oauth meta data fetch."""

    def __init__(self, cfg: PlatformConfig, **kwargs):
        self.platform_config = cfg
        self.workflows_instance_config: InstanceConfig = kwargs["workflows_instance_config"]

    def _try_fetch_client_config(self) -> dict:
        """Fetches the ClientConfig from auth metadata service."""
        endpoint = self.platform_config.endpoint
        protocol = "http" if self.platform_config.insecure else "https"
        verify = True
        if self.platform_config.insecure_skip_verify:
            verify = False
        elif self.platform_config.ca_cert_file_path:
            verify = self.platform_config.ca_cert_file_path
        url = f"{protocol}://{endpoint}{AUTH_META_DATA_ENDPOINT}"

        try:
            resp = requests.get(url=url, verify=verify, timeout=60)
            if resp.status_code == CODE_OK:
                return resp.json()
            else:
                msg = f"Error while fetching auth metadata from {url}: {resp.status_code}, {resp.text}"
                raise RuntimeError(msg)

        except requests.exceptions.RequestException as e:
            msg = dedent(
                f"""\
                Couldn't reach Workflows backend due to connectivity issue.
                Before reaching out to support channel please checkout our troubleshooting guide here:
                https://helix.docs.swf.i.mercedes-benz.com/helix-documentation/products/compute/workflows/troubleshooting/submitting_workflows/#networklogin-issues

                Additionally please find our availability dashboard here:
                https://grafana.{self.workflows_instance_config.gcp_dns}/d/workflows-availability-dashboard/workflows-backend-availability-indicators"""
            )
            raise RuntimeError(msg) from e

    def get_client_config(self) -> ClientConfig:
        """Returns the ClientConfig."""
        # Fetches JSON defined here:
        # https://git.swf.i.mercedes-benz.com/helix/Workflows/-/tree/main/infra/k8s/env/mercedes-benz/prod/argo-app-auth-gw.yaml?ref_type=heads
        public_client_config = self._try_fetch_client_config()
        device_authorization_endpoint = public_client_config.get("device_authorization_endpoint")
        audience = public_client_config.get("audience")

        return ClientConfig(
            token_endpoint=public_client_config["token_endpoint"],
            authorization_endpoint=public_client_config["authorization_endpoint"],
            redirect_uri=public_client_config["redirect_uri"],
            client_id=public_client_config["client_id"],
            scopes=public_client_config["scopes"],
            header_key=public_client_config["header_key"],
            device_authorization_endpoint=device_authorization_endpoint,
            audience=audience,
        )


def upgrade_channel_to_authenticated(cfg: PlatformConfig, in_channel: grpc.Channel, **kwargs) -> grpc.Channel:
    """Given a grpc.Channel, preferably a secure channel, it returns a composed channel.

    That in turn uses Interceptor to perform an Oauth2.0 Auth flow.
    Implementation is merely copied over from flytekit/clients/auth_helper.upgrade_channel_to_authenticated

    :param cfg: PlatformConfig
    :param in_channel: grpc.Channel Precreated channel
    :return: grpc.Channel. New composite channel
    """

    def authenticator_factory():
        return get_authenticator(cfg, WorkflowsRemoteClientConfigStore(cfg, **kwargs))

    return grpc.intercept_channel(in_channel, AuthUnaryInterceptor(authenticator_factory))


class SynchronousWorkflowsClient(SynchronousFlyteClient):
    """Worklows implementation of SynchronousFlyteClient to control _channel creation."""

    def __init__(self, cfg: PlatformConfig, **kwargs):
        """Initializes a gRPC channel to the given Flyte Admin service.

        Implementation is merely copied over from flytekit/clients/raw.RawSynchronousFlyteClient.__init__

        Args:
          cfg: PlatformConfig.
          kwargs: Various options
        """
        # Set the value here to match the limit in Admin, otherwise the client will cut off and the user gets a
        # StreamRemoved exception.
        # https://github.com/flyteorg/flyte/blob/e8588f3a04995a420559327e78c3f95fbf64dc01/flyteadmin/pkg/common/constants.go#L14
        # 32KB for error messages, 20MB for actual messages.
        options = (("grpc.max_metadata_size", 32 * 1024), ("grpc.max_receive_message_length", 20 * 1024 * 1024))
        self._cfg = cfg
        self._channel = wrap_exceptions_channel(
            cfg,
            upgrade_channel_to_authenticated(cfg, get_channel(cfg, options=options), **kwargs),
        )
        self._stub = _admin_service.AdminServiceStub(self._channel)
        self._signal = signal_service.SignalServiceStub(self._channel)
        self._dataproxy_stub = dataproxy_service.DataProxyServiceStub(self._channel)

        logger.info(
            f"Flyte Client configured -> {self._cfg.endpoint} in {'insecure' if self._cfg.insecure else 'secure'} mode."
        )
        # metadata will hold the value of the token to send to the various endpoints.
        self._metadata = None


class WorkflowsRemote(FlyteRemote):
    """Worklows implementation of FlyteRemote to control SynchronousFlyteClient creation."""

    @property
    def client(self) -> SynchronousFlyteClient:
        """Return a SynchronousFlyteClient for additional operations."""
        if not self._client_initialized:
            self._client = self._determine_auth_client(**self._kwargs)
            self._client_initialized: bool = True
        return self._client

    def _determine_auth_client(self, **kwargs) -> SynchronousFlyteClient:
        if "workflows_infra" not in kwargs.keys() or "workflows_instance_config" not in kwargs.keys():
            return SynchronousFlyteClient(self.config.platform, **self._kwargs)

        workflows_infra: Infra = kwargs["workflows_infra"]
        if workflows_infra in [Infra.Dev, Infra.Prod]:
            return SynchronousWorkflowsClient(self.config.platform, **self._kwargs)

        return SynchronousFlyteClient(self.config.platform, **self._kwargs)

    @classmethod
    def from_client_and_secret(
        cls,
        client_id: str,
        client_secret: str,
        domain: Domain,
        team_space: str,
        instance: Instance = Instance.MB,
        infra: Infra = Infra.Prod,
    ) -> "WorkflowsRemote":
        """Factory that returns new WorkflowsRemote with auth mode "Client Credentials".

        Returned WorflowsRemote instance is suitable for tech users only.

        Args:
          client_id: ClientID of TE-USER managed via IAMAT
          client_secret: ClientSecret of TE-USER managed via IAMAT
          domain: Domain [Dev|Prod]
          team_space: Team space task belongs to.
          instance: Instance [MB|LOCAL]. Can be omitted.
          infra: Infra [Dev|Prod]. Can be omitted.
        """
        instance_config = get_instances_config(instance, infra)
        endpoint = f"{instance_config.flyte_host}:{80 if instance is Instance.LOCAL else 443}"
        auth_mode = AuthType.CLIENT_CREDENTIALS

        remote = cls(
            config=FlyteConfig(
                platform=PlatformConfig(
                    endpoint=endpoint,
                    insecure=True if instance is Instance.LOCAL else False,
                    insecure_skip_verify=True if instance is Instance.LOCAL else False,
                    auth_mode=auth_mode,
                    client_id=client_id,
                    client_credentials_secret=client_secret,
                    ca_cert_file_path=certifi.where(),
                )
            ),
            default_domain=domain.value,
            default_project=team_space,
            workflows_infra=infra,
            workflows_instance_config=instance_config,
        )

        return remote

    @classmethod
    def from_client(
        cls,
        client_id: str,
        domain: Domain,
        team_space: str,
        instance: Instance = Instance.MB,
        infra: Infra = Infra.Prod,
    ) -> "WorkflowsRemote":
        """Factory that returns new WorkflowsRemote with auth mode "Client Credentials".

        Returned WorflowsRemote instance is suitable for tech users only. By default client secret
        is going to be loaded from ".config/hlx-cli/credentials.json".

        Args:
          client_id: ClientID of TE-USER managed via IAMAT
          domain: Domain [Dev|Prod]
          team_space: Team space task belongs to.
          instance: Instance [MB|LOCAL]. Can be omitted.
          infra: Infra [Dev|Prod]. Can be omitted.
        """
        credentials: Credentials = Credentials.get_credentials()
        oidc_client_secret = credentials.flyte_oidc_client_credentials

        return cls.from_client_and_secret(
            client_id=client_id,
            client_secret=oidc_client_secret,
            domain=domain,
            team_space=team_space,
            instance=instance,
            infra=infra,
        )
