"""Kubernetes secrets as environment variables handling."""

from dataclasses import dataclass

from kubernetes.client.models import V1EnvVar, V1EnvVarSource, V1SecretKeySelector


@dataclass
class KubernetesSecretEnv:
    """Kubernetes Secret to mount as environment variable."""

    secret_name: str
    secret_key: str

    def to_kubernetes_ref(self, env_name: str):
        """Creates a V1EnvVar entry."""
        return V1EnvVar(
            name=env_name,
            value_from=V1EnvVarSource(secret_key_ref=V1SecretKeySelector(name=self.secret_name, key=self.secret_key)),
        )
