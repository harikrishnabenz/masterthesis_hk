"""Init of hlx.wf.

We also add imports from flytekit directly here, to make imports looking nicer when working with hlx.wf.
"""

from flytekit.core.base_task import TaskMetadata, kwtypes
from flytekit.core.workflow import workflow
from flytekit.image_spec.image_spec import ImageSpec

from hlx.wf.cluster import GPUAccelerator
from hlx.wf.compute import DedicatedAccNode, DedicatedNode, SharedNode
from hlx.wf.container_images import ContainerImage
from hlx.wf.kubernetes import Resources
from hlx.wf.kubernetes_secrets import KubernetesSecretEnv
from hlx.wf.nodepool import Node
from hlx.wf.runtime_tooling import fuse_prefetch_metadata, start_debugging
from hlx.wf.task import BazelTarget, ContainerTask, WorkingDirImage, dynamic, task

__all__ = [
    "BazelTarget",
    "ContainerImage",
    "ContainerTask",
    "DedicatedAccNode",
    "DedicatedNode",
    "GPUAccelerator",
    "ImageSpec",
    "KubernetesSecretEnv",
    "Node",
    "Resources",
    "SharedNode",
    "TaskMetadata",
    "WorkingDirImage",
    "dynamic",
    "fuse_prefetch_metadata",
    "kwtypes",
    "start_debugging",
    "task",
    "workflow",
]
