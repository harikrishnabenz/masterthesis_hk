"""Cache abstractions to simplify usage."""

from dataclasses import dataclass
from typing import Any, Callable, Optional

import flytekit

from hlx.wf.bazel import BazelTarget
from hlx.wf.blackbox import BlackboxContainerTarget
from hlx.wf.container_images import ImageType, WorkingDirImage


@dataclass
class CacheSettings:
    """Typing defining values for cache, cache_serialize, and cache_version."""

    cache: bool
    cache_serialize: bool
    cache_version: str


@dataclass
class CacheContext:
    """Typing defining values used to determine CacheSettings."""

    image: Optional[ImageType]
    flyte_task: Optional[Callable[..., Any]]


class Cache:
    """Typing used to implement concrete caching behavior."""

    def settings_from_context(self, context: CacheContext) -> CacheSettings:  # noqa: ARG002
        """Constucts and returns settings required to instrument caching.

        Result gets passed to original task decorator of Flytekit.

        Return:
            cacheSettings defining values for cache, cache_serialize, and cache_version
        """
        return CacheSettings(False, False, "")


class CacheNone(Cache):
    """Typing to indicate no caching should be involved."""


class CacheWherePossible(Cache):
    """Typing to involve caching as much as possible.

    Note: Changing function signature or its input causes cache being invalidated.
    """

    def settings_from_context(self, context: CacheContext) -> CacheSettings:  # noqa: D102, ARG002
        return CacheSettings(True, False, "CacheWherePossible")


class CacheByVersion(Cache):
    """Typing to utilize versioned cache data.

    Use this if you need to switch between different cache versions.
    Define your own versioning. Subsequent runs having same versions would cause
    cache hit then.

    Note: Changing function signature or its input causes cache being invalidated.

    Args:
        version: Unique identifier used to create or lookup cached data.
    """

    def __init__(self, version: str):
        self.version = version

    def settings_from_context(self, context: CacheContext) -> CacheSettings:  # noqa: D102, ARG002
        return CacheSettings(True, False, self.version)


class CacheSameImageOnly(Cache):
    """Typing to utilize cache which invalidates in case of a container image change.

    Note: Changing function signature or its input causes cache being invalidated.
    """

    def settings_from_context(self, context: CacheContext) -> CacheSettings:  # noqa: D102
        working_dir = ""
        if isinstance(context.image, WorkingDirImage):
            working_dir = f"{context.image.working_dir}-"
            context.image = context.image.value

        if isinstance(context.image, BazelTarget):
            if not context.flyte_task or not isinstance(context.flyte_task, Callable):  # type: ignore
                msg = "Flyte task function must be present in case image is type of BazelTarget"
                raise ValueError(msg)
            container_image = context.image.get_container_image(context.flyte_task)
        elif isinstance(context.image, flytekit.ImageSpec):
            container_image = context.image.tag
        elif isinstance(context.image, BlackboxContainerTarget):
            container_image = context.image.get_container_image()
        else:
            container_image = str(context.image)

        return CacheSettings(True, False, f"{working_dir}{container_image}")


def wrapper_cache_settings(cache: Optional[Cache]) -> Callable[..., CacheSettings]:
    """Builds a function that comprises cache settings for a flyte task.

    A parametrized function is required in order to evaluate cache settings
    of flyte in actual task wrapper. Currently BazelTarget is the only reason
    why we have to place it there.

    Args:
        cache: Param forwarded from task decorator.
        cache_serialize: Param forwarded from task decorator.
        cache_version: Param forwarded from task decorator.
    """

    def cache_settings(context: CacheContext) -> CacheSettings:
        if cache is None:
            return CacheNone().settings_from_context(context)

        if not isinstance(cache, Cache):
            msg = "Param 'cache' must be an instance of Cache. Use CacheWherePossible(), CacheByVersion(), or CacheSameImageOnly() instead."  # noqa: E501
            raise ValueError(msg)

        return cache.settings_from_context(context)

    return cache_settings
