"""Utilities for tasks built using Bazel."""

import os
import re
from pathlib import Path
from typing import Callable, Optional

INVALID_BAZEL_TARGET = "unknown-image-wrong-bazel-target-specified?"
MAX_NUMBER_ENV_VARS = 100


class BazelTarget:
    """A bazel target."""

    def _get_target_name(self, task_fn: Callable):
        return f"{task_fn.__module__.split('.')[-1]}.{task_fn.__name__}"

    def get_container_image(self, task_fn: Callable) -> str:
        """Get the container image from bazel."""
        env = f"HELIX_IMAGE__{self._get_target_name(task_fn).upper().replace('.', '__')}"
        # we cannot know at this point whether this is an error
        return os.environ.get(env, INVALID_BAZEL_TARGET)

    def get_task_env_vars(self, task_fn: Callable) -> dict[str, str]:
        """Retrieves environment variables from bazel."""
        # note the indirection. This env variable stores the env variables to be set for the task
        target_name = self._get_target_name(task_fn)
        if not re.match(r"^[\w.]+$", target_name):
            msg = f"Invalid target name {target_name}"
            raise ValueError(msg)

        # Construct the environment variable name safely
        task_env_vars_var = f"HELIX_TASK_ENV__{target_name.upper().replace('.', '__')}"
        if task_env_vars_var in os.environ:
            task_env_vars = os.environ[task_env_vars_var].split(" ")
            # set a limit for all env vars
            if len(task_env_vars) > MAX_NUMBER_ENV_VARS:
                msg = f"""Unsupported amount of environment variables set for {target_name}.
                Allowed: {MAX_NUMBER_ENV_VARS}, provided: {len(task_env_vars)}"""
                raise ValueError(msg)
            return {env: os.environ[env] for env in task_env_vars if env in os.environ}
        return {}

    def get_working_dir(self, task_fn: Callable) -> Optional[str]:
        """Retrieves the working directory from bazel."""
        working_dir_var = f"HELIX_WORKING_DIR__{self._get_target_name(task_fn).upper().replace('.', '__')}"
        return os.environ.get(working_dir_var, None)


def runtime_path(targetname: str, runfiles_hint: Optional[Path] = None) -> Path:
    """Returns the location of a target at runtime within a task.

    Args:
        targetname: The name of a (executable) target to locate. Should be fully qualified,
            e.g. "@workspace//path/to:targetname".
        runfiles_hint:  A hint to the location of the runfiles root. If not provided, (or not existent) the
        function will attempt to guess it.

    Returns:
        The location of the target at runtime.
    """
    runfiles = guess_runfiles_root(runfiles_hint)
    local_path = targetname.lstrip("@").replace("//", "/").replace(":", "/")
    path = (runfiles / local_path).absolute()
    if not path.exists():
        runfiles = guess_runfiles_root()
        path = (runfiles / local_path).absolute()
        if not path.exists():
            msg = f"Could not find runtime path for target {targetname}, expected {path}"
            raise ValueError(msg)
    return path


def guess_runfiles_root(runfiles_hint: Optional[Path] = None) -> Path:
    """Returns the path to the current runfiles root.

    The process of finding the runfiles root is a bit involved. This function
    attempts to guess it by looking searching for a folder named something.runfiles in either
    the wd or this scripts path.
    If you are looking for a specific runfiles root, you can pass it as an argument.

    Args:
        runfiles_hint: A hint to the location of the runfiles root. If not provided,
        (or not existent) the function will attempt to guess it.

    Returns:
        The path to the bazel runfiles root directory
    """

    def locate_runfiles_root(child_dir: Path) -> Optional[Path]:
        return next(
            (path for path in child_dir.parents if path.name.endswith(".runfiles")),
            None,
        )

    if runfiles_hint and runfiles_hint.exists():
        return runfiles_hint.absolute()

    helix_runfiles_root_env = os.environ.get("HELIX_RUNFILES_ROOT")
    if helix_runfiles_root_env and Path(helix_runfiles_root_env).exists():
        return Path(os.environ["HELIX_RUNFILES_ROOT"])

    root = locate_runfiles_root(Path.cwd())
    if not root:
        root = locate_runfiles_root(Path(__file__))
    if not root:
        msg = f"Could not find runfiles root (cwd = {Path.cwd()})"
        raise ValueError(msg)
    return root
