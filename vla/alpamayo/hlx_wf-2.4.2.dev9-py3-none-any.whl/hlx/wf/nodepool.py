"""List of all available nodes in our cluster."""

from enum import Enum

from hlx.wf.cluster import ARMCPUNode, CPUNode, DwsStatus, GPUAccelerator, GPUNode, TPUAccelerator, TPUNode


class Node(Enum):
    """Nodepools that are available."""

    A100_40GB_1GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_40GB,
        gpu_number="1",
        cpu="12",
        mem="85G",
        ephemeral_storage="1500G",
        dws=DwsStatus.DISABLED,
    )
    A100_40GB_2GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_40GB,
        gpu_number="2",
        cpu="24",
        mem="170G",
        ephemeral_storage="1500G",
        dws=DwsStatus.DISABLED,
    )
    A100_40GB_4GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_40GB,
        gpu_number="4",
        cpu="48",
        mem="340G",
        ephemeral_storage="1500G",
        dws=DwsStatus.DISABLED,
    )
    A100_40GB_8GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_40GB,
        gpu_number="8",
        cpu="96",
        mem="680G",
        ephemeral_storage="3000G",
        dws=DwsStatus.DISABLED,
    )
    A100_40GB_16GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_40GB,
        gpu_number="16",
        cpu="96",
        mem="1360G",
        ephemeral_storage="3000G",
        dws=DwsStatus.DISABLED,
    )
    A100_80GB_1GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_80GB,
        gpu_number="1",
        cpu="12",
        mem="170G",
        ephemeral_storage="375G",
        dws=DwsStatus.ENABLED,
    )
    A100_80GB_2GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_80GB,
        gpu_number="2",
        cpu="24",
        mem="340G",
        ephemeral_storage="750G",
        dws=DwsStatus.ENABLED,
    )
    A100_80GB_4GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_80GB,
        gpu_number="4",
        cpu="48",
        mem="680G",
        ephemeral_storage="1500G",
        dws=DwsStatus.ENABLED,
    )
    A100_80GB_8GPU = GPUNode(
        gpu_type=GPUAccelerator.A100_80GB,
        gpu_number="8",
        cpu="96",
        mem="1360G",
        ephemeral_storage="3000G",
        dws=DwsStatus.ENABLED,
    )
    V100_1GPU = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="1",
        cpu="8",
        mem="52G",
        ephemeral_storage="375G",
        dws=DwsStatus.DISABLED,
    )
    V100_2GPU = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="2",
        cpu="16",
        mem="104G",
        ephemeral_storage="375G",
        dws=DwsStatus.DISABLED,
    )
    V100_4GPU = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="4",
        cpu="32",
        mem="208G",
        ephemeral_storage="375G",
        dws=DwsStatus.DISABLED,
    )
    V100_8GPU = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="8",
        cpu="64",
        mem="416G",
        ephemeral_storage="1500G",
        dws=DwsStatus.DISABLED,
    )
    V100_1GPU_MAX = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="1",
        cpu="12",
        mem="78G",
        ephemeral_storage="3000G",
        selection_label="nvidia-tesla-v100-max-1",
        dws=DwsStatus.DISABLED,
    )
    V100_2GPU_MAX = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="2",
        cpu="24",
        mem="158G",
        ephemeral_storage="375G",
        selection_label="nvidia-tesla-v100-max-2",
        dws=DwsStatus.DISABLED,
    )
    V100_4GPU_MAX = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="4",
        cpu="48",
        mem="312G",
        ephemeral_storage="375G",
        selection_label="nvidia-tesla-v100-max-4",
        dws=DwsStatus.DISABLED,
    )
    V100_8GPU_MAX = GPUNode(
        gpu_type=GPUAccelerator.V100,
        gpu_number="8",
        cpu="96",
        mem="624G",
        ephemeral_storage="1500G",
        selection_label="nvidia-tesla-v100-max-8",
        dws=DwsStatus.DISABLED,
    )
    L4_1GPU = GPUNode(
        gpu_type=GPUAccelerator.L4,
        gpu_number="1",
        cpu="16",
        mem="64G",
        ephemeral_storage="375G",
        dws=DwsStatus.ENABLED,
    )
    L4_2GPU = GPUNode(
        gpu_type=GPUAccelerator.L4,
        gpu_number="2",
        cpu="24",
        mem="96G",
        ephemeral_storage="750G",
        dws=DwsStatus.ENABLED,
    )
    L4_4GPU = GPUNode(
        gpu_type=GPUAccelerator.L4,
        gpu_number="4",
        cpu="48",
        mem="192G",
        ephemeral_storage="1500G",
        dws=DwsStatus.ENABLED,
    )
    L4_8GPU = GPUNode(
        gpu_type=GPUAccelerator.L4,
        gpu_number="8",
        cpu="96",
        mem="384G",
        ephemeral_storage="3000G",
        dws=DwsStatus.ENABLED,
    )
    H100_80GB_8GPU = GPUNode(
        gpu_type=GPUAccelerator.H100,
        gpu_number="8",
        cpu="208",
        mem="1872G",
        ephemeral_storage="6000G",
        dws=DwsStatus.ENABLED,
    )
    P100_1GPU = GPUNode(
        gpu_type=GPUAccelerator.P100,
        gpu_number="1",
        cpu="16",
        mem="104G",
        ephemeral_storage="375G",
        dws=DwsStatus.DISABLED,
    )
    P100_2GPU = GPUNode(
        gpu_type=GPUAccelerator.P100,
        gpu_number="2",
        cpu="32",
        mem="208G",
        ephemeral_storage="750G",
        dws=DwsStatus.DISABLED,
    )
    P100_4GPU = GPUNode(
        gpu_type=GPUAccelerator.P100,
        gpu_number="4",
        cpu="96",
        mem="624G",
        ephemeral_storage="1500G",
        dws=DwsStatus.DISABLED,
    )
    T4_1GPU = GPUNode(
        gpu_type=GPUAccelerator.T4,
        gpu_number="1",
        cpu="16",
        mem="104G",
        ephemeral_storage="375G",
        dws=DwsStatus.DISABLED,
    )
    T4_2GPU = GPUNode(
        gpu_type=GPUAccelerator.T4,
        gpu_number="2",
        cpu="32",
        mem="208G",
        ephemeral_storage="375G",
        dws=DwsStatus.DISABLED,
    )
    T4_4GPU = GPUNode(
        gpu_type=GPUAccelerator.T4,
        gpu_number="4",
        cpu="96",
        mem="624G",
        ephemeral_storage="1500G",
        dws=DwsStatus.DISABLED,
    )

    CPU_8 = CPUNode(
        cpu="8",
        mem="32G",
        ephemeral_storage="375G",
    )
    CPU_16 = CPUNode(
        cpu="16",
        mem="64G",
        ephemeral_storage="750G",
    )
    CPU_32 = CPUNode(
        cpu="32",
        mem="128G",
        ephemeral_storage="1500G",
    )
    CPU_64 = CPUNode(
        cpu="64",
        mem="256G",
        ephemeral_storage="3000G",
    )
    CPU_128 = CPUNode(
        cpu="128",
        mem="512G",
        ephemeral_storage="6000G",
    )

    ARM_CPU_4 = ARMCPUNode(
        cpu="4",
        mem="16G",
        ephemeral_storage="375G",
    )
    ARM_CPU_8 = ARMCPUNode(
        cpu="8",
        mem="32G",
        ephemeral_storage="750G",
    )
    ARM_CPU_16 = ARMCPUNode(
        cpu="16",
        mem="64G",
        ephemeral_storage="1500G",
    )
    ARM_CPU_32 = ARMCPUNode(
        cpu="32",
        mem="128G",
        ephemeral_storage="2250G",
    )
    ARM_CPU_48 = ARMCPUNode(
        cpu="48",
        mem="192G",
        ephemeral_storage="3750G",
    )
    ARM_CPU_72 = ARMCPUNode(
        cpu="72",
        mem="288G",
        ephemeral_storage="6000G",
    )

    #  sub-host (1/8 * 180 CPUs v6e ) https://cloud.google.com/tpu/docs/v6e#configurations
    TPUV6_1T_1x1 = TPUNode(
        tpu_accelerator=TPUAccelerator.V6E,
        tpu_number_per_vm="1",
        topology="1x1",
        cpu="22",
        mem="176G",
        ephemeral_storage="1500G",
    )

    #  sub-host (1/2 * 180 CPUs v6e) https://cloud.google.com/tpu/docs/v6e#configurations
    TPUV6_4T_2x2 = TPUNode(
        tpu_accelerator=TPUAccelerator.V6E,
        tpu_number_per_vm="4",
        topology="2x2",
        cpu="90",
        mem="720G",
        ephemeral_storage="1500G",
    )
    # Multi Node TPU is not supported yet
    # TPUV6_4T_4x4 = TPUNode(
    #    tpu_accelerator=TPUAccelerator.V6E,
    #    tpu_number_per_vm="4",
    #    topology="4x4",
    #    cpu="180",
    #    mem="720G",
    #    ephemeral_storage="1500G",
    # )

    # full host (180 CPUs v6e) https://cloud.google.com/tpu/docs/v6e#configurations
    TPUV6_8T_2x4 = TPUNode(
        tpu_accelerator=TPUAccelerator.V6E,
        tpu_number_per_vm="8",
        topology="2x4",
        cpu="180",
        mem="1440G",
        ephemeral_storage="1500G",
    )
