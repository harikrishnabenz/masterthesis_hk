"""Definition of mount types."""

import csv
import re
from enum import IntEnum
from io import StringIO
from pathlib import Path
from typing import Optional, Union

from kubernetes.client.models import V1EmptyDirVolumeSource, V1SecretVolumeSource, V1Volume, V1VolumeMount

from hlx.wf.config import get_helix_instance, get_infra_helix_environment
from hlx.wf.kubernetes import HumanReadableUnit, PodFeature

MOUNTPOINT = Path("/mnt")
SHM_MAX_VALUE = "max"
BUCKET_CSV = """\
    instance,  teamspace,            stage,   bucket
    MB,        Data-adjustment,      dev,     mbadas-sandbox-data-adjustment-94a821d
    MB,        Data-adjustment,      prod,    mbadas-sandbox-data-adjustment-9a38426
    MB,        Data-hive,            dev,     mbadas-sandbox-data-hive-c6f4d18
    MB,        Data-hive,            prod,    mbadas-sandbox-data-hive-9507728
    MB,        Data-proc-prod,       dev,     mbadas-sandbox-data-proc-prod-e0f141c
    MB,        Data-proc-prod,       prod,    mbadas-sandbox-data-proc-prod-ed7032f
    MB,        Data-processing,      dev,     mbadas-sandbox-data-processing-7aeef2e
    MB,        Data-processing,      prod,    mbadas-sandbox-data-processing-e93701b
    MB,        Dataset-manager,      dev,     mbadas-sandbox-dataset-manager-f73d88a
    MB,        Dataset-manager,      prod,    mbadas-sandbox-dataset-manager-e9410c3
    MB,        Digital-testing,      dev,     mbadas-sandbox-digital-testing-2cee94d
    MB,        Digital-testing,      prod,    mbadas-sandbox-digital-testing-581a10f
    MB,        Dev-exp,              dev,     mbadas-sandbox-dev-exp-77a4f0b
    MB,        Dev-exp,              prod,    mbadas-sandbox-dev-exp-4bbfb5c
    MB,        Foam,                 dev,     mbadas-sandbox-foam-76b5fb9
    MB,        Foam,                 prod,    mbadas-sandbox-foam-a8f5d20
    MB,        Ingest,               dev,     mbadas-sandbox-ingest-907630f
    MB,        Ingest,               prod,    mbadas-sandbox-ingest-8c78ba2
    MB,        Intention-detection,  dev,     mbadas-sandbox-intention-detection-f888663
    MB,        Intention-detection,  prod,    mbadas-sandbox-intention-detection-5c42c33
    MB,        Interior-sensing,     dev,     mbadas-sandbox-interior-sensing-a2d095f
    MB,        Interior-sensing,     prod,    mbadas-sandbox-interior-sensing-c0f47d9
    MB,        Labeling,             dev,     mbadas-sandbox-labeling-c41752f
    MB,        Labeling,             prod,    mbadas-sandbox-labeling-5d118f9
    MB,        Lidar,                dev,     mbadas-sandbox-lidar-039f3ef
    MB,        Lidar,                prod,    mbadas-sandbox-lidar-47b964c
    MB,        Localization,         dev,     mbadas-sandbox-localization-9e6ccaf
    MB,        Localization,         prod,    mbadas-sandbox-localization-c950335
    MB,        Map-learning,         dev,     mbadas-sandbox-map-learning-88f0479
    MB,        Map-learning,         prod,    mbadas-sandbox-map-learning-d231208
    MB,        Minerva-data-eng,     dev,     mbadas-sandbox-minerva-data-eng-423f04c
    MB,        Minerva-data-eng,     prod,    mbadas-sandbox-minerva-data-eng-93380f8
    MB,        Minerva-data,         dev,     mbadas-sandbox-minerva-data-99d22ca
    MB,        Minerva-data,         prod,    mbadas-sandbox-minerva-data-081068e
    MB,        Mbadas-aitools,       dev,     mbadas-sandbox-mbadas-aitools-8c00bf4
    MB,        Mbadas-aitools,       prod,    mbadas-sandbox-mbadas-aitools-e52df9d
    MB,        Mbadas-vlm,           dev,     mbadas-sandbox-mbadas-vlm-96a79ba
    MB,        Mbadas-vlm,           prod,    mbadas-sandbox-mbadas-vlm-3d04d28
    MB,        Mli,                  dev,     mbadas-sandbox-mli-14163cf
    MB,        Mli,                  prod,    mbadas-sandbox-mli-a8991ec
    MB,        Nautilus-Dataset,     dev,     mbadas-sandbox-nautilus-dataset-87c8efd
    MB,        Nautilus-Dataset,     prod,    mbadas-sandbox-nautilus-dataset-d757dca
    MB,        Nautilus-Eval,        dev,     mbadas-sandbox-nautilus-eval-56b04ba
    MB,        Nautilus-Eval,        prod,    mbadas-sandbox-nautilus-eval-a7f0ef6
    MB,        Nautilus-Gd,          dev,     mbadas-sandbox-nautilus-gd-def89ef
    MB,        Nautilus-Gd,          prod,    mbadas-sandbox-nautilus-gd-ce1be6a
    MB,        Nautilus-Ld,          dev,     mbadas-sandbox-nautilus-ld-3027146
    MB,        Nautilus-Ld,          prod,    mbadas-sandbox-nautilus-ld-34e7ade
    MB,        Nautilus-Od,          dev,     mbadas-sandbox-nautilus-od-0dada91
    MB,        Nautilus-Od,          prod,    mbadas-sandbox-nautilus-od-aa9f9cf
    MB,        Ndas,                 dev,     mbadas-sandbox-ndas-628b208
    MB,        Ndas,                 prod,    mbadas-sandbox-ndas-c758fb0
    MB,        Neural-recon,         dev,     mbadas-sandbox-neural-recon-ddd1a10
    MB,        Neural-recon,         prod,    mbadas-sandbox-neural-recon-259d8d6
    MB,        Operations,           dev,     mbadas-sandbox-operations-060a1fc
    MB,        Operations,           prod,    mbadas-sandbox-operations-ca60c5f
    MB,        Playground,           dev,     mbadas-sandbox-playground-454b485
    MB,        Playground,           prod,    mbadas-sandbox-playground-44e6bd8
    MB,        Radar,                dev,     mbadas-sandbox-radar-23ff624
    MB,        Radar,                prod,    mbadas-sandbox-radar-cdcf74d
    MB,        Recompute,            dev,     mbadas-sandbox-recompute-9c469e0
    MB,        Recompute,            prod,    mbadas-sandbox-recompute-8a4a8f0
    MB,        Research,             dev,     mbadas-sandbox-research-8798e02
    MB,        Research,             prod,    mbadas-sandbox-research-9bb9c7f
    MB,        Road-estimation,      dev,     mbadas-sandbox-road-estimation-9159236
    MB,        Road-estimation,      prod,    mbadas-sandbox-road-estimation-72e2c91
    MB,        Scene-mining,         dev,     mbadas-sandbox-scene-mining-072e1c6
    MB,        Scene-mining,         prod,    mbadas-sandbox-scene-mining-90452ee
    MB,        Shape,                dev,     mbadas-sandbox-shape-060d8ce
    MB,        Shape,                prod,    mbadas-sandbox-shape-ca46074
    MB,        Tabular-Mb,           dev,     mbadas-sandbox-tabular-mb-df3cebf
    MB,        Tabular-Mb,           prod,    mbadas-sandbox-tabular-mb-960205d
    MB,        Vital-sensing,        dev,     mbadas-sandbox-vital-sensing-43a3cbb
    MB,        Vital-sensing,        prod,    mbadas-sandbox-vital-sensing-82a0f22
"""


class CsvColumn(IntEnum):
    """Enum for CSV columns in the bucket CSV file."""

    INSTANCE = 0
    TEAMSPACE = 1
    STAGE = 2
    BUCKET = 3


def _parse_bucket_list(csv_table: str) -> list[list[str]]:
    """Parse the bucket CSV table into a list."""
    return list(csv.reader(StringIO(csv_table), delimiter=",", skipinitialspace=True))


bucket_list = _parse_bucket_list(BUCKET_CSV)


def _lookup_bucket(teamspace: str) -> str:
    buckets = []
    for row in bucket_list:
        if (
            row[CsvColumn.TEAMSPACE] == teamspace
            and row[CsvColumn.INSTANCE] == get_helix_instance().upper()
            and row[CsvColumn.STAGE] == get_infra_helix_environment().lower()
        ):
            buckets.append(row[CsvColumn.BUCKET])
    if len(buckets) == 0:
        # Sadly, we cannot raise an error here as team spaces
        # are hard coded as class members regardless of current
        # Helix instance.
        return f"Sandbox bucket not defined for {teamspace}"

    if len(buckets) > 1:
        msg = "Too many sandbox buckets found"
        raise ValueError(msg)

    return buckets[0]


class MountType(PodFeature):
    """Typing for arbitrary mount implementation.

    Feel free to take this as base to specify your own mount.
    """

    def __init__(self, name: str, mount_path: Optional[Union[str, Path]]):
        super().__init__()
        resource_check_pattern = re.compile("[a-z0-9][-a-z0-9]*")
        if not resource_check_pattern.fullmatch(name):
            error_msg = (
                f"The given name ({name}) is not allowed in kubernetes."
                "Names need to start with a-z0-9 and may only contain"
                "lower case characters, numbers and -."
            )
            raise ValueError(error_msg)

        self.name = name
        self.mount_path = MOUNTPOINT / name if mount_path is None else Path(mount_path)

    def mountpoint(self) -> Path:
        """Returns the path the volume is mounted to."""
        return self.mount_path

    def storage_reservation(self) -> HumanReadableUnit:
        """Returns the storage reservation of the mount."""
        return HumanReadableUnit("0Gi")

    def volumes(self) -> list[V1Volume]:
        """Returns list of volume specs."""
        return []


class FuseBucket(MountType):
    """Mounts a bucket.

    Note: Please make sure that the uid and guid fit to the user in the docker image.

    Args:
        bucket: Path to the bucket.
        name: Name of the mount and will be used to generate a mounting in /mnt/{name}.
        prefix: Prefix (subfolder) inside the bucket that should be mounted.
        uid: UID used to mount the bucket.
        gid: GID used to mount the bucket.
        read_only: If True, the mount is read only.
        optimize_random_access: Should be True if files in GCS FUSE are not read sequentially.
    """

    Data_Adjustment = _lookup_bucket("Data-adjustment")
    Data_Hive = _lookup_bucket("Data-hive")
    Data_Proc_Prod = _lookup_bucket("Data-proc-prod")
    Data_Processing = _lookup_bucket("Data-processing")
    Dataset_Manager = _lookup_bucket("Dataset-manager")
    Dev_Exp = _lookup_bucket("Dev-exp")
    Digital_testing = _lookup_bucket("Digital-testing")
    Foam = _lookup_bucket("Foam")
    Ingest = _lookup_bucket("Ingest")
    Intention_detection = _lookup_bucket("Intention-detection")
    Interior_sensing = _lookup_bucket("Interior-sensing")
    Labeling = _lookup_bucket("Labeling")
    Lidar = _lookup_bucket("Lidar")
    Localization = _lookup_bucket("Localization")
    Map_learning = _lookup_bucket("Map-learning")
    Minerva_Data_Eng = _lookup_bucket("Minerva-data-eng")
    Minerva_Data = _lookup_bucket("Minerva-data")
    Mbadas_Aitools = _lookup_bucket("Mbadas-aitools")
    Mbadas_Vlm = _lookup_bucket("Mbadas-vlm")
    Mli = _lookup_bucket("Mli")
    Nautilus_Dataset = _lookup_bucket("Nautilus-Dataset")
    Nautilus_Eval = _lookup_bucket("Nautilus-Eval")
    Nautilus_Gd = _lookup_bucket("Nautilus-Gd")
    Nautilus_Ld = _lookup_bucket("Nautilus-Ld")
    Nautilus_Od = _lookup_bucket("Nautilus-Od")
    Ndas = _lookup_bucket("Ndas")
    Neural_Recon = _lookup_bucket("Neural-recon")
    Operations = _lookup_bucket("Operations")
    Playground = _lookup_bucket("Playground")
    Radar = _lookup_bucket("Radar")
    Recompute = _lookup_bucket("Recompute")
    Research = _lookup_bucket("Research")
    Road_Estimation = _lookup_bucket("Road-estimation")
    Scene_Mining = _lookup_bucket("Scene-mining")
    Shape = _lookup_bucket("Shape")
    Tabular_Mb = _lookup_bucket("Tabular-Mb")
    Vital_Sensing = _lookup_bucket("Vital-sensing")

    def __init__(
        self,
        bucket: str,
        name: str,
        prefix: str = "",
        uid: int = 1000,
        gid: int = 1000,
        read_only=True,  # noqa: FBT002
        mount_path: Optional[str] = None,
        storage_reservation: HumanReadableUnit = HumanReadableUnit("30Gi"),  # noqa: B008
        optimize_random_access: bool = False,  # noqa: FBT002
    ):
        super().__init__(name, mount_path)
        self.bucket = bucket
        self.read_only = read_only
        self.prefix = prefix
        self.uid = uid
        self.gid = gid
        self._storage_reservation = storage_reservation
        self.optimize_random_access = optimize_random_access

    def volume_mounts(self) -> list[V1VolumeMount]:  # noqa: D102
        result = super().volume_mounts()

        result += [
            V1VolumeMount(
                name=self.name,
                read_only=self.read_only,
                mount_path=self.mountpoint().as_posix(),
            )
        ]

        return result

    def volumes(self) -> list[V1Volume]:  # noqa: D102
        result = super().volume_mounts()

        only_dir_flag = ""
        if self.prefix != "":
            only_dir_flag = f"only-dir={self.prefix},"
        result += [
            V1Volume(
                name=self.name,
                csi={
                    "driver": "gcsfuse.csi.storage.gke.io",
                    "readOnly": self.read_only,
                    "volumeAttributes": {
                        "bucketName": self.bucket,
                        "mountOptions": (
                            f"{only_dir_flag}implicit-dirs,uid={self.uid},gid={self.gid},"
                            # We found this parameters helpful for getting a good FUSE performance.
                            "http-client-timeout=5s,metadata-cache-ttl-secs=86400,stat-cache-max-size-mb=-1"
                        ),
                    },
                },
            )
        ]
        return result

    def storage_reservation(self) -> HumanReadableUnit:  # noqa: D102
        return self._storage_reservation


class RamDisk(MountType):
    """Mounts a disk in memory (ramdisk).

    Args:
        name: Name of the mount and will be used to generate a mounting in /mnt/{name}.
    """

    def __init__(
        self,
        name: str,
        size_limit: Optional[Union[HumanReadableUnit, str]],
        mount_path: Optional[str] = None,
    ):
        super().__init__(name, mount_path)
        self.size_limit = size_limit

    def volume_mounts(self) -> list[V1VolumeMount]:  # noqa: D102
        result = super().volume_mounts()

        result += [
            V1VolumeMount(
                name=self.name,
                mount_path=self.mountpoint().as_posix(),
            )
        ]

        return result

    def volumes(self) -> list[V1Volume]:  # noqa: D102
        result = super().volume_mounts()

        size_limit = self.size_limit.base_unit() if isinstance(self.size_limit, HumanReadableUnit) else self.size_limit

        result = [
            V1Volume(
                name=self.name,
                empty_dir=V1EmptyDirVolumeSource(medium="Memory", size_limit=size_limit),
            )
        ]

        return result


class ShdMem(RamDisk):
    """Reservates and mounts part of memory to be used as shared memory.

    Mounted path is "/dev/shm".

    Args:
        size_limit: Size of RAM available for sharing and IPC purposes.
    """

    def __init__(
        self,
        size_limit: Optional[Union[HumanReadableUnit, str]],
    ):
        super().__init__("dshm", size_limit, "/dev/shm")  # noqa: S108

    def volumes(self) -> list[V1Volume]:  # noqa: D102
        if self.size_limit == SHM_MAX_VALUE:
            empty_dir_volume_source = V1EmptyDirVolumeSource(medium="Memory")
        elif isinstance(self.size_limit, HumanReadableUnit):
            size_limit = self.size_limit.base_unit()
            empty_dir_volume_source = V1EmptyDirVolumeSource(medium="Memory", size_limit=size_limit)
        else:
            empty_dir_volume_source = V1EmptyDirVolumeSource(medium="Memory", size_limit=self.size_limit)

        result = [
            V1Volume(
                name=self.name,
                empty_dir=empty_dir_volume_source,
            )
        ]

        return result


class KubernetesSecret(MountType):
    """Mounts a Kubernetes secret into a container's file system.

    Args:
        name: Name of the mount and will be used to generate a mounting in /mnt/{name}.
            Will also be used as the volume name.
        secret_name: Kubernetes secret to mount
        mount_path: POSIX path under which to mount the secret
    """

    def __init__(
        self,
        name: str,
        secret_name: str,
        mount_path: Optional[Union[str, Path]] = None,
    ):
        super().__init__(name, mount_path)
        self.volume_name = name
        self.secret_name = secret_name

    def volume_mounts(self) -> list[V1VolumeMount]:  # noqa: D102
        result = super().volume_mounts()

        result += [
            V1VolumeMount(
                name=self.volume_name,
                read_only=True,
                mount_path=self.mountpoint().as_posix(),
            )
        ]

        return result

    def volumes(self) -> list[V1Volume]:  # noqa: D102
        result = super().volume_mounts()

        result += [
            V1Volume(
                name=self.volume_name,
                secret=V1SecretVolumeSource(secret_name=self.secret_name),
            ),
        ]
        return result
