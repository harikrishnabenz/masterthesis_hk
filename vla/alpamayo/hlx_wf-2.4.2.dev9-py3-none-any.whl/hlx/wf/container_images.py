"""Set of container image definitions."""

import os
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Union

from flytekit.image_spec.image_spec import ImageSpec

from hlx.wf.__about__ import __version__
from hlx.wf.bazel import BazelTarget
from hlx.wf.blackbox import BlackboxContainerTarget
from hlx.wf.config import get_docker_registry
from hlx.wf.loggers import logger

DEPENDENCIES_PIP: list[str] = ["hlx_wf", "fsspec[gcs]"]
DEPENDENCIES_APT: list[str] = []
PIP_REGISTRY = "https://europe-west4-python.pkg.dev/mb-adas-2015-p-a4db/hlx-wf-pypi-virtual/simple/"
DOCKER_REPO = get_docker_registry(helix_infra_environment=None, helix_instance=None)

ImageType = Union[str, ImageSpec, BazelTarget, BlackboxContainerTarget, "WorkingDirImage"]


@dataclass
class WorkingDirImage:
    """In case you need to modify the default working dir for your image.

    The default working_dir of flyte is the one of the image. In case your image needs a different one,
    feel free to use this class to specify a working dir for your image.
    The working_dir is used for uploading and executing the workflows on the pods filesystem.
    """

    working_dir: str
    value: Optional[Union[str, ImageSpec, BazelTarget]] = None


class ContainerImage(str, Enum):
    """List of prebuilt container images that have all dependencies installed to run on HLX Workflows."""

    PYTHON_3_8 = (
        f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_py:3.8py-{__version__}"
    )
    """Just Python 3.8 and everything that is need to run on HLX Workflows."""
    PYTHON_3_9 = (
        f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_py:3.9py-{__version__}"
    )
    """Just Python 3.9 and everything that is need to run on HLX Workflows."""
    PYTHON_3_10 = (
        f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_py:3.10py-{__version__}"
    )
    """Just Python 3.10 and everything that is need to run on HLX Workflows."""
    PYTHON_3_11 = (
        f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_py:3.11py-{__version__}"
    )
    """Just Python 3.11 and everything that is need to run on HLX Workflows."""

    PYTHON_3_11_ARM = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_py:3.11py-arm64-{__version__}"  # noqa: E501
    """Just Python 3.11 on ARM64 and everything that is need to run on HLX Workflows."""

    CUDA_11_8_PYTHON_3_9 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_cuda:11.8.0-runtime-3.9py-{__version__}"  # noqa: E501
    """11.8.0 CUDA Docker image with Python 3.9."""
    CUDA_11_8_PYTHON_3_10 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_cuda:11.8.0-runtime-3.10py-{__version__}"  # noqa: E501
    """11.8.0 CUDA Docker image with Python 3.10."""
    CUDA_11_8_PYTHON_3_11 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_cuda:11.8.0-runtime-3.11py-{__version__}"  # noqa: E501
    """11.8.0 CUDA Docker image with Python 3.11."""
    CUDA_12_1_PYTHON_3_9 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_cuda:12.1.0-runtime-3.9py-{__version__}"  # noqa: E501
    """12.1.0 CUDA Docker image with Python 3.9."""
    CUDA_12_1_PYTHON_3_10 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_cuda:12.1.0-runtime-3.10py-{__version__}"  # noqa: E501
    """12.1.0 CUDA Docker image with Python 3.10."""
    CUDA_12_1_PYTHON_3_11 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_cuda:12.1.0-runtime-3.11py-{__version__}"  # noqa: E501
    """12.1.0 CUDA Docker image with Python 3.11."""

    PYTORCH_CUDA_11_8_PYTHON_3_9 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch:11.8.0-runtime-3.9py-{__version__}"  # noqa: E501
    """Pytorch based on 11.8.0 CUDA Docker image with Python 3.9."""
    PYTORCH_CUDA_11_8_PYTHON_3_10 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch:11.8.0-runtime-3.10py-{__version__}"  # noqa: E501
    """Pytorch based on 11.8.0 CUDA Docker image with Python 3.10."""
    PYTORCH_CUDA_11_8_PYTHON_3_11 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch:11.8.0-runtime-3.11py-{__version__}"  # noqa: E501
    """Pytorch based on 11.8.0 CUDA Docker image with Python 3.11."""
    PYTORCH_CUDA_12_1_PYTHON_3_9 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch:12.1.0-runtime-3.9py-{__version__}"  # noqa: E501
    """Pytorch based on 12.1.0 CUDA Docker image with Python 3.9."""
    PYTORCH_CUDA_12_1_PYTHON_3_10 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch:12.1.0-runtime-3.10py-{__version__}"  # noqa: E501
    """Pytorch based on 12.1.0 CUDA Docker image with Python 3.10."""
    PYTORCH_CUDA_12_1_PYTHON_3_11 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch:12.1.0-runtime-3.11py-{__version__}"  # noqa: E501
    """Pytorch based on 12.1.0 CUDA Docker image with Python 3.11."""

    PYTORCH_HOROVOD_CUDA_11_6_PYTHON_3_9 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch_horovod:11.6.1-devel-3.9py-{__version__}"  # noqa: E501
    """Pytorch with all requirements to run it in a multi-node setting with Horovod / MPI
    with CUDA 11.6.1 and Python 3.9."""
    PYTORCH_HOROVOD_CUDA_11_6_PYTHON_3_10 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_pytorch_horovod:11.6.1-devel-3.10py-{__version__}"  # noqa: E501
    """Pytorch with all requirements to run it in a multi-node setting with Horovod / MPI
    with CUDA 11.6.1 and Python 3.10."""

    SPARK = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_spark:{__version__}"
    """Spark environment including Python3 and flyte's spark plugin."""

    RAY_PYTORCH_CUDA_12_1_PYTHON_3_10 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_ray_pytorch:cu121-310py-{__version__}"  # noqa: E501
    """Ray with Pytorch with CUDA 12.1 and Python 3.10."""
    RAY_PYTORCH_CUDA_12_1_PYTHON_3_11 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_ray_pytorch:cu121-311py-{__version__}"  # noqa: E501
    """Ray with Pytorch with CUDA 12.1 and Python 3.11."""

    XLA_PYTHON_3_11 = f"{get_docker_registry(helix_infra_environment=None, helix_instance=None)}/flyte/hlx_wf_xla:3.11py-xla2.5.0-{__version__}"  # noqa: E501
    """XLA 2.5.0 and Python 3.11."""

    @staticmethod
    def default() -> str:
        """Return default container image used for tasks."""
        return ContainerImage.PYTHON_3_10.value


def determine_container_image(container_image: Optional[ImageType] = None) -> ImageType:
    """Determines finaly container image to be used to run task on.

    For testing purposes we allow container images be overridden via env var 'HLX_TASK_IMAGE'
    """
    env_name_for_image = "HLX_TASK_IMAGE"
    if env_name_for_image in os.environ.keys():
        env_specified_image = os.environ.get(env_name_for_image)
        if env_specified_image is None:
            msg = f"Environment variable {env_name_for_image} is not set."
            raise ValueError(msg)
        if not isinstance(env_specified_image, str) or not env_specified_image.strip():
            msg = f"Environment variable {env_name_for_image} must be a non-empty string."
            raise ValueError(msg)
        logger.warning(f"Overriding container images used for task(s) to: {env_specified_image}")
        return env_specified_image
    elif isinstance(container_image, WorkingDirImage):
        if container_image.value is None:
            msg = "WorkingDirImage must have a value set."
            raise ValueError(msg)
        return container_image.value
    elif container_image is None:
        return ContainerImage.default()
    else:
        return container_image
