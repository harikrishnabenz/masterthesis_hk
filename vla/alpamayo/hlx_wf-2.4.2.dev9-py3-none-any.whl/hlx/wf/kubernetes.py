"""Define features that build on top of kubernetes."""

import re
from functools import total_ordering
from typing import Any, Callable, Optional, Union, cast

from flytekit.core.resources import Resources as FlyteResources
from kubernetes.client.models import V1Volume, V1VolumeMount

K8S_GPU_RESOURCE_KEY = "nvidia.com/gpu"

UNITS = {
    "m": 10**-3,
    None: 1,
    "": 1,
    "K": 10**3,
    "M": 10**6,
    "G": 10**9,
    "T": 10**12,
    "Ki": 2**10,
    "Mi": 2**20,
    "Gi": 2**30,
    "Ti": 2**40,
}


@total_ordering
class HumanReadableUnit:
    """A class for holding and parsing units from a human readable string.

    In Kubernetes units are defined as strings, as described here:
    https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
    https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/quantity/
    """

    def __init__(self, value: Union[None, float, str, "HumanReadableUnit"], forbid_zero=True) -> None:  # noqa: FBT002
        """Constructor.

        Args:
            value: A quantity, either a number or a string with a unit (e.g. 2G or 3Mi)
            forbid_zero: Raise an exception if value is "0" or None
        """
        if isinstance(value, (float, int)):
            self.number_str = str(value)
            self.unit = ""
            self.number = value
        elif value is None:
            self.number_str = "0"
            self.unit = ""
            self.number = 0
        elif isinstance(value, HumanReadableUnit):
            self.number_str = value.number_str
            self.unit = value.unit
            self.number = value.number
        else:
            m = re.match(r"^(\d+(?:\.\d+)?)\s*([KMGTm]?i?)?$", value)
            if m:
                self.number_str, self.unit = cast(tuple[str, str], m.groups())
                self.number = float(self.number_str)
            else:
                msg = f"{value} is an invalid human readable size."
                raise ValueError(msg)
        if forbid_zero and self.number_str == "0":
            msg = "Zero values are not allowed."
            raise ValueError(msg)

    def __add__(self, other: "HumanReadableUnit") -> "HumanReadableUnit":
        """Adding two HumanReadableUnit objects.

        Args:
            other: The other HumanReadableUnit object.

        Returns:
            A new HumanReadableUnit object.
        """
        return HumanReadableUnit(str(self.base_unit() + other.base_unit()), forbid_zero=False)

    def __sub__(self, other: "HumanReadableUnit") -> "HumanReadableUnit":
        """Subtract HumanReadableUnit.

        Args:
            other: The other HumanReadableUnit object.

        Returns:
            A new HumanReadableUnit object.
        """
        return HumanReadableUnit(str(self.base_unit() - other.base_unit()), forbid_zero=False)

    def __mul__(self, scalar: float) -> "HumanReadableUnit":
        """Scale HumanReadableUnit.

        Args:
            scalar: Scalar to be applied on HumanReadableUnit object.

        Returns:
            A new HumanReadableUnit object.
        """
        return HumanReadableUnit(str(self.base_unit() * scalar), forbid_zero=False)

    def __eq__(self, other: Any) -> bool:
        """Compares two HumanReadableUnit objects."""
        if isinstance(other, str):
            return self.number_str == other
        elif isinstance(self, HumanReadableUnit):
            return self.base_unit() == other.base_unit()
        return False

    def __lt__(self, other: "HumanReadableUnit") -> bool:
        """Compares two HumanReadableUnit objects."""
        return self.base_unit() < other.base_unit()

    def __hash__(self) -> int:
        """Hash of the object."""
        return hash(self.base_unit())

    def base_unit(self) -> float:
        """Returning the number as base unit.

        Note: Depending on the input, also friction of a number can be returned, e.g. 100.2.

        Returns:
            The number as base unit.
        """
        return self.number * UNITS[self.unit]

    def base_unit_rounded(self) -> int:
        """Returning the number as base unit. Rounded to whole numbers.

        Returns:
            The number as base unit.
        """
        return int(self.base_unit())

    def value(self, unit: str) -> float:
        """Returning the number in a specified unit.

        Args:
            unit: Unit to convert to.

        Returns:
            The number in the specified unit.
        """
        return self.base_unit() / UNITS[unit]

    def value_rounded(self, unit: str, precision: int = 2) -> float:
        """Returning the number in a specified unit rounded to whole numbers.

        Args:
            unit: Unit to convert to.
            precision: The number of decimal places for rounding (2 by default)

        Returns:
            The number in the specified unit.
        """
        return round(self.base_unit_rounded() / UNITS[unit], precision)

    def __str__(self) -> str:
        """String representation of the object."""
        return self.number_str + self.unit

    def __repr__(self) -> str:
        """Representation of the object."""
        return f"'{self.__str__()}'"


class PodFeature:
    """A interface for implementing a feature as pod spec."""

    def volume_mounts(self) -> list[V1VolumeMount]:
        """K8s volume mounts needed.

        Returns:
            List of those.
        """
        return []

    def volumes(self) -> list[V1Volume]:
        """K8s volumes needed.

        Returns:
            List of those.
        """
        return []

    def init_hooks(self) -> list[Callable[[], None]]:
        """Define which functions should be execute before anything else.

        Those will be executed before the function provided as "task" and can be used to prepare the environment.

        Returns:
            List of those.
        """
        return []


class Resources(FlyteResources):
    """This class is used to specify both resource requests and resource limits.

    .. code-block:: python

        Resources(cpu="1", mem="2048")  # This is 1 CPU and 2 KB of memory
        Resources(cpu="100m", mem="2Gi")  # This is 1/10th of a CPU and 2 gigabytes of memory

        # For Kubernetes-based tasks, pods use ephemeral local storage for scratch space, caching, and for logs.
        # This allocates 1Gi of such local storage.
        Resources(ephemeral_storage="1Gi")

    .. note::

        Persistent storage is not currently supported on the Flyte backend.

    Please see the :std:ref:`User Guide <cookbook:customizing task resources>` for detailed examples.
    Also refer to the `K8s conventions. <https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/#resource-units-in-kubernetes>`__
    """

    def __add__(self, other: Optional["Resources"]) -> "Resources":
        """Adding two Resources objects.

        Args:
            other: The other HumanReadableUnit object.

        Returns:
            Same but modified Resources object.
        """
        result = Resources()

        if not other:
            other = Resources()

        for attr in ["cpu", "mem", "ephemeral_storage", "gpu"]:
            if not getattr(self, attr) and getattr(other, attr):
                setattr(result, attr, getattr(other, attr))
            elif getattr(self, attr) and not getattr(other, attr):
                setattr(result, attr, getattr(self, attr))
            elif getattr(self, attr) and getattr(other, attr):
                setattr(
                    result, attr, str(HumanReadableUnit(getattr(self, attr)) + HumanReadableUnit(getattr(other, attr)))
                )

        return result

    def __radd__(self, other: Optional["Resources"]) -> "Resources":
        """Adding two Resources objects.

        Args:
            other: The other HumanReadableUnit object.

        Returns:
            Same but modified Resources object.
        """
        return self.__add__(other)

    def __sub__(self, other: "Resources") -> "Resources":
        """Subtract Resources object.

        Args:
            other: The other Resources object.

        Returns:
            Same but modified Resources object.
        """
        result = Resources()

        if not other:
            other = Resources()

        for attr in ["cpu", "mem", "ephemeral_storage", "gpu"]:
            if getattr(self, attr) and getattr(other, attr):
                self_val = HumanReadableUnit(getattr(self, attr))
                other_val = HumanReadableUnit(getattr(other, attr))
                if self_val.base_unit() > other_val.base_unit():
                    setattr(result, attr, str(self_val - other_val))
                else:
                    setattr(result, attr, None)
            elif getattr(self, attr) and not getattr(other, attr):
                setattr(result, attr, getattr(self, attr))

        return result

    def __eq__(self, other):
        """Compares two Resources objects.

        Args:
            other: The other Resources object.

        Returns:
            bool
        """
        if not isinstance(other, Resources):
            return False

        def get_base_unit(self_or_other, attr) -> float:
            val = getattr(self_or_other, attr)
            if val:
                return HumanReadableUnit(val, forbid_zero=False).base_unit()
            else:
                return 0.0

        attributes = ["cpu", "mem", "ephemeral_storage", "gpu"]
        return all(get_base_unit(self, attr) == get_base_unit(other, attr) for attr in attributes)

    def __hash__(self):
        """Generates hash from self.

        Returns:
            int
        """
        return hash(self)

    @staticmethod
    def from_v1_container_resource(con_res: dict) -> "Resources":
        """Creates new Resource instance by resource dict of a V1Container.

        Args:
            con_res: Resources dictionary of a V1Container instance.

        Returns:
            Equivalent Resources object.
        """
        if not con_res:
            return Resources()

        return Resources(
            cpu=con_res["cpu"] if "cpu" in con_res else None,
            mem=con_res["memory"] if "memory" in con_res else None,
            ephemeral_storage=con_res["ephemeral-storage"] if "ephemeral-storage" in con_res else None,
            gpu=con_res[K8S_GPU_RESOURCE_KEY] if K8S_GPU_RESOURCE_KEY in con_res else None,
        )

    def __str__(self) -> str:  # noqa: D105
        return f"gpu_number: {self.gpu}, cpu: {self.cpu}, mem: {self.mem}, ephemeral_storage: {self.ephemeral_storage}"
