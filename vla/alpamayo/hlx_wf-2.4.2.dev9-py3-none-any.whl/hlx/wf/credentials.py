"""Credentials handling for the HLX CLI. Partially ported from helix-cli/src/hlx_cli/lib/core/credentials.py."""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from dataclasses_json import DataClassJsonMixin

from hlx.wf.config import HLX_CONFIG_DIR
from hlx.wf.loggers import logger


@dataclass
class Credentials(DataClassJsonMixin):
    """Credentials for the HLX CLI."""

    flyte_oidc_client_credentials: Optional[str] = None

    def __post_init__(self):
        """Post-initialization hook, initializes the path attribute."""
        self.path: Optional[Path] = None

    @classmethod
    def get_credentials(cls) -> "Credentials":
        """Obtains the CLI config, initializing it interatively if necessary."""
        path = cls.default_credentials_file()
        if not path.exists():
            msg = f"Could not load credentials as file not found: {path}"
            raise RuntimeError(msg)
        else:
            logger.info(f"Loading credentials from {path}")
            credentials = cls.load_credentials(path)

        return credentials

    @classmethod
    def default_config_folder(cls) -> Path:
        """Returns the default credentials folder."""
        if HLX_CONFIG_DIR in os.environ:
            return Path(os.environ[HLX_CONFIG_DIR])
        return Path.home() / ".config" / "hlx-cli"

    @classmethod
    def default_credentials_file(cls) -> Path:
        """Returns the default credentials file."""
        return cls.default_config_folder() / "credentials.json"

    @classmethod
    def load_credentials(cls, path: Optional[Path] = None) -> "Credentials":
        """Loads the configuration from the given path or the default path."""
        if path is None:
            path = cls.default_credentials_file()
        with path.open() as f:
            credentials = Credentials.from_json(f.read())  # type: ignore
        credentials.path = path
        return credentials
