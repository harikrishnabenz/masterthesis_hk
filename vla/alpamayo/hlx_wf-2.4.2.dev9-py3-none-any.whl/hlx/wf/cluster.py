"""Definition of resources in the helix cluster."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, fields
from enum import Enum
from typing import Optional, Union

from hlx.wf.kubernetes import HumanReadableUnit

KUEUE_JOB_KEY = "kueue-job"
KUEUE_LOCAL_QUEUE_KEY = "kueue.x-k8s.io/queue-name"
KUEUE_LOCAL_QUEUE_NON_DWS = "local-queue"
KUEUE_LOCAL_QUEUE_DWS = "dws-local-queue"
DWS_MAX_DURATION_SECONDS = 604800  # 7 days
DWS_MIN_DURATION_SECONDS = 600
DEFAULT_MAX_DURATION = DWS_MAX_DURATION_SECONDS + 60 * 60
TPU_ACCELERATORS_ANNOTATION_KEY = "tpu-accelerators"
SIDECAR_MEM_SIZE = HumanReadableUnit("2.5Gi")
CPU_BASE_WORKLOADS = HumanReadableUnit(3)


class GPUAccelerator(str, Enum):
    """GPU Accelerator type."""

    V100 = "nvidia-tesla-v100"
    A100_40GB = "nvidia-tesla-a100"
    A100_80GB = "nvidia-a100-80gb"
    L4 = "nvidia-l4"
    H100 = "nvidia-h100-80gb"
    P100 = "nvidia-tesla-p100"
    T4 = "nvidia-tesla-t4"


class DwsStatus(str, Enum):
    """DWS Status."""

    DISABLED = "disabled"
    ENABLED = "enabled"
    RECOMMENDED = "recommended"


class TPUAccelerator(str, Enum):
    """TPU Accelerator Type."""

    V6E = "tpu-v6e-slice"


StrOrHumanReadableUnit = Union[str, HumanReadableUnit]


@dataclass(frozen=True, order=True)
class NodeBase(ABC):
    """Base class for the different node types available in the hlx cluster."""

    cpu: HumanReadableUnit
    mem: HumanReadableUnit
    ephemeral_storage: HumanReadableUnit

    def __init__(
        self,
        cpu: StrOrHumanReadableUnit,
        mem: StrOrHumanReadableUnit,
        ephemeral_storage: StrOrHumanReadableUnit,
    ) -> None:
        # Need to use object.__setattr__ because dataclass is frozen.
        object.__setattr__(self, "cpu", HumanReadableUnit(cpu))
        object.__setattr__(self, "mem", HumanReadableUnit(mem))
        # allowing zeros for ephemeral storage because we sometimes create temporary node objects
        # with zero storage. Validity of "real" nodes is checked in the validate method.
        object.__setattr__(self, "ephemeral_storage", HumanReadableUnit(ephemeral_storage, forbid_zero=False))

    @abstractmethod
    def node_selector(self) -> dict[str, str]:
        """Returns selectors for selecting the node."""
        raise NotImplementedError

    @abstractmethod
    def node_selector_dws(self, max_node_duration: Optional[int] = 604800) -> dict[str, str]:
        """Returns selectors for selecting the node.

        Args:
            max_node_duration: The duration in seconds, for which a node needs to be scheduled.
        """
        raise NotImplementedError

    @abstractmethod
    def pod_annotations(self) -> dict[str, str]:
        """Returns additional annotations meant for pod spec."""
        raise NotImplementedError

    @abstractmethod
    def pod_labels(self) -> dict[str, str]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        raise NotImplementedError

    def all_greater_equal(self, other: "NodeBase") -> bool:
        """Check if all resources are greater or equal to the ones of the other node.

        Note that a.all_greater_equal(b) != b.all_greater_equal(a) because the comparison is not symmetric.
        """
        if type(self) is not type(other):
            msg = f"Cannot compare different types of nodes: {type(self)} and {type(other)}"
            raise ValueError(msg)
        return all(getattr(self, f.name) >= getattr(other, f.name) for f in fields(self) if f.compare)

    def validate(self):
        """Validate the node."""
        if self.ephemeral_storage.base_unit() == 0:
            msg = "Ephemeral storage cannot be zero."
            raise ValueError(msg)
        if self.cpu <= CPU_BASE_WORKLOADS:
            msg = f"You need more than ({CPU_BASE_WORKLOADS}) CPU for basic node services."
            raise ValueError(msg)

        if self.mem < SIDECAR_MEM_SIZE:
            msg = f"Memory is not sufficient for sidecar ({SIDECAR_MEM_SIZE})."
            raise ValueError(msg)


@dataclass(frozen=True, order=True)
class CPUNode(NodeBase):
    """Node Type for CPU-only nodes."""

    selection_label: str = field(compare=False)

    def __init__(
        self,
        cpu: StrOrHumanReadableUnit,
        mem: StrOrHumanReadableUnit,
        ephemeral_storage: StrOrHumanReadableUnit,
        selection_label: Optional[str] = None,
    ) -> None:
        super().__init__(cpu, mem, ephemeral_storage)
        object.__setattr__(self, "selection_label", selection_label if selection_label else f"cpu-dedicated-{cpu}")

    def node_selector(self) -> dict[str, str]:
        """Returns selectors for selecting the node."""
        return {"cloud.google.com/compute-class": self.selection_label}

    def node_selector_dws(self, _max_node_duration: Optional[int] = 604800) -> dict[str, str]:
        """Returns selectors for DWS-enabled node. For CPU nodes, return an error."""
        msg = "DWS is not available for CPU-only nodes."
        raise ValueError(msg)

    def pod_annotations(self) -> dict[str, str]:
        """Returns additional annotations meant for pod spec."""
        return {}

    def pod_labels(self) -> dict[str, str]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        return {KUEUE_JOB_KEY: "false"}


@dataclass(frozen=True, order=True)
class ARMCPUNode(NodeBase):
    """Node Type for ARM CPU-only nodes."""

    selection_label: str = field(compare=False)

    def __init__(
        self,
        cpu: StrOrHumanReadableUnit,
        mem: StrOrHumanReadableUnit,
        ephemeral_storage: StrOrHumanReadableUnit,
        selection_label: Optional[str] = None,
    ) -> None:
        super().__init__(cpu, mem, ephemeral_storage)
        object.__setattr__(self, "selection_label", selection_label if selection_label else f"arm-cpu-dedicated-{cpu}")

    def node_selector(self) -> dict[str, str]:
        """Returns selectors for selecting the node."""
        return {
            "cloud.google.com/compute-class": self.selection_label,
            "kubernetes.io/arch": "arm64",
        }

    def node_selector_dws(self, _max_node_duration: Optional[int] = 604800) -> dict[str, str]:
        """Returns selectors for DWS-enabled node. For ARM CPU nodes, return an error."""
        msg = "DWS is not available for ARM CPU-only nodes."
        raise ValueError(msg)

    def pod_annotations(self) -> dict[str, str]:
        """Returns additional annotations meant for pod spec."""
        return {}

    def pod_labels(self) -> dict[str, str]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        return {KUEUE_JOB_KEY: "false"}


@dataclass(frozen=True, order=True)
class GPUNode(NodeBase):
    """Node Type for GPU accelerated nodes."""

    gpu_type: GPUAccelerator
    gpu_number: HumanReadableUnit
    selection_label: str
    dws: DwsStatus

    def __init__(
        self,
        gpu_type: GPUAccelerator,
        gpu_number: StrOrHumanReadableUnit,
        cpu: StrOrHumanReadableUnit,
        mem: StrOrHumanReadableUnit,
        ephemeral_storage: StrOrHumanReadableUnit,
        selection_label: Optional[str] = None,
        dws: DwsStatus = DwsStatus.RECOMMENDED,  # To be removed
    ) -> None:
        super().__init__(cpu, mem, ephemeral_storage)
        object.__setattr__(self, "gpu_type", gpu_type)
        object.__setattr__(self, "gpu_number", HumanReadableUnit(gpu_number))
        object.__setattr__(
            self, "selection_label", selection_label if selection_label else f"{gpu_type.value}-{gpu_number}"
        )
        object.__setattr__(self, "dws", dws)

    def node_selector(self) -> dict[str, str]:
        """Returns selectors for selecting the node."""
        return {
            "cloud.google.com/compute-class": self.selection_label,
        }

    def node_selector_dws(self, max_node_duration: Optional[int] = 604800) -> dict[str, str]:
        """Returns selectors for selecting the node.

        Args:
            max_node_duration: The duration in seconds, for which a node needs to be scheduled.
        """
        return {
            "cloud.google.com/compute-class": f"{self.selection_label}-dws",
            "cloud.google.com/gke-max-run-duration-seconds": f"{max_node_duration}",
        }

    def pod_annotations(self) -> dict[str, str]:
        """Returns additional annotations meant for pod spec.

        Return:
            A Dict of annotations.
        """
        return {}

    def pod_labels(self) -> dict[str, str]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        kueue = KUEUE_LOCAL_QUEUE_NON_DWS if self.dws == DwsStatus.DISABLED else KUEUE_LOCAL_QUEUE_DWS
        return {KUEUE_JOB_KEY: "true", KUEUE_LOCAL_QUEUE_KEY: kueue}


@dataclass(frozen=True, order=True)
class TPUNode(NodeBase):
    """Node Type for TPU accelerated nodes."""

    tpu_accelerator: TPUAccelerator
    tpu_number_per_vm: HumanReadableUnit
    topology: str

    def __init__(
        self,
        tpu_accelerator: TPUAccelerator,
        tpu_number_per_vm: str,
        topology: str,
        cpu: str,
        mem: str,
        ephemeral_storage: str,
    ) -> None:
        super().__init__(cpu, mem, ephemeral_storage)
        object.__setattr__(self, "tpu_accelerator", tpu_accelerator)
        object.__setattr__(self, "tpu_number_per_vm", HumanReadableUnit(tpu_number_per_vm))
        object.__setattr__(self, "topology", topology)

    def node_selector(self) -> dict[str, str]:
        """Returns additional labels meant for pod spec."""
        return {
            "cloud.google.com/compute-class": f"tpu-v6e-slice-{self.tpu_number_per_vm}t-{self.topology}",
            "cloud.google.com/gke-tpu-accelerator": self.tpu_accelerator.value,
            "cloud.google.com/gke-tpu-topology": self.topology,
        }

    def node_selector_dws(self, _max_node_duration: Optional[int] = 604800) -> dict[str, str]:
        """Returns selectors for DWS-enabled node. For TPU nodes, return an error."""
        msg = "DWS is not available for TPU nodes."
        raise ValueError(msg)

    def pod_annotations(self) -> dict[str, str]:
        """Returns additional annotations meant for pod spec.

        Return:
            A Dict of annotations.
        """
        return {TPU_ACCELERATORS_ANNOTATION_KEY: str(self.tpu_number_per_vm)}

    def pod_labels(self) -> dict[str, str]:
        """Returns additional labels meant for pod spec.

        Return:
            A Dict of labels.
        """
        return {KUEUE_JOB_KEY: "true", KUEUE_LOCAL_QUEUE_KEY: KUEUE_LOCAL_QUEUE_NON_DWS}
